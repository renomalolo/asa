// Titik masuk aplikasi: inisialisasi, navigasi sederhana, banner pemutar.
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, BackHandler, Platform, StatusBar, Text, View } from 'react-native';
import * as Notifications from 'expo-notifications';
import { muatData, cfg } from './src/store';
import { S, usePlayerUI } from './src/state';
import { Tombol, WARNA, s } from './src/ui';
import {
  hentikanAudioDanSimpan, pastikanFolder, salinAudioBawaan, siapkanModeAudio,
} from './src/audio';
import { mulaiMesin, mulaiWatchdog } from './src/engine';
import { deteksiLokasiOtomatis, lokasiPerluDicek, mulaiLoopLokasi } from './src/lokasi';
import { ambilTanggalHijriyah } from './src/api';
import Utama from './src/screens/Utama';
import { AdzanTarhim, MemoriMurottal } from './src/screens/PilihanAudio';
import { Lokasi, ProfilLokasi } from './src/screens/Lokasi';
import Selisih from './src/screens/Selisih';
import Fitur from './src/screens/Fitur';
import { AudioVolume, Cerdas, Diagnostik, Durasi, Panduan, Sunnah, SuaraTTS, Tentang } from './src/screens/Pengaturan';
import { Alarm, Hijriyah, JadwalHarian, Jawa, Kiblat, TesAudio } from './src/screens/Alat';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
});

const LAYAR = {
  Utama, AdzanTarhim, MemoriMurottal, Lokasi, Selisih, Fitur, Sunnah, AudioVolume, Durasi, Cerdas, SuaraTTS,
  TesAudio, Profil: ProfilLokasi, Diagnostik, Panduan, Tentang, Kiblat, Hijriyah, Jawa, JadwalHarian, Alarm,
};

function Banner() {
  const p = usePlayerUI();
  if (!p.aktif) return null;
  return (
    <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: '#FFF', borderTopWidth: 1, borderColor: '#999', padding: 10 }}>
      <Text style={s.teks}>{'Sedang Mengudara: ' + p.judul.toUpperCase()}</Text>
      <Tombol teks="HENTIKAN SIARAN" warna="#F44336" onPress={hentikanAudioDanSimpan} />
    </View>
  );
}

export default function App() {
  const [siap, setSiap] = useState(false);
  const [status, setStatus] = useState('Memuat...');
  const [tumpukan, setTumpukan] = useState(['Utama']);
  const ref = useRef(tumpukan); ref.current = tumpukan;

  useEffect(() => {
    (async () => {
      await muatData();
      try {
        if (Platform.OS === 'android') {
          await Notifications.setNotificationChannelAsync('jadwal', { name: 'Jadwal Salat', importance: Notifications.AndroidImportance.HIGH });
        }
        await Notifications.requestPermissionsAsync();
      } catch (e) {}
      pastikanFolder();
      await siapkanModeAudio();
      await salinAudioBawaan(setStatus);
      setSiap(true);
      ambilTanggalHijriyah(0).then((h) => { S.bulanHijriyahIni = (h && h.bln) || ''; });
      mulaiMesin(1000); mulaiWatchdog(); mulaiLoopLokasi();
      setTimeout(() => { if (cfg.lokasiOtomatis && lokasiPerluDicek()) deteksiLokasiOtomatis(cfg.kota !== 'Belum Diatur'); }, 2500);
    })();
  }, []);

  const nav = {
    ke: useCallback((n) => setTumpukan((t) => [...t, n]), []),
    kembali: useCallback(() => setTumpukan((t) => (t.length > 1 ? t.slice(0, -1) : t)), []),
    awal: useCallback(() => setTumpukan(['Utama']), []),
  };

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (ref.current.length > 1) { nav.kembali(); return true; }
      return false; // di menu utama: aplikasi disembunyikan, mesin tetap jalan
    });
    return () => sub.remove();
  }, []);

  if (!siap) {
    return (
      <View style={[s.layar, { alignItems: 'center', justifyContent: 'center', padding: 24 }]}>
        <ActivityIndicator size="large" />
        <Text style={s.teks}>{'Jadwal Salat by Reno\n' + status}</Text>
      </View>
    );
  }
  const Layar = LAYAR[tumpukan[tumpukan.length - 1]] || Utama;
  return (
    <View style={{ flex: 1 }}>
      <StatusBar barStyle="dark-content" />
      <Layar nav={nav} />
      <Banner />
    </View>
  );
}
