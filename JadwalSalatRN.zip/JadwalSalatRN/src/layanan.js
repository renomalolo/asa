// Layanan latar depan Android (react-native-background-actions).
// Tanpa ini, timer JS berhenti saat aplikasi di latar belakang / layar mati.
import BackgroundService from 'react-native-background-actions';

const opsi = {
  taskName: 'JadwalSalat',
  taskTitle: 'Jadwal Salat by Reno',
  taskDesc: 'Mesin jadwal aktif',
  taskIcon: { name: 'ic_launcher', type: 'mipmap' },
  color: '#4CAF50',
  linkingURI: 'jadwalsalat://',
};

// Tugas headless: sekadar tetap hidup sampai layanan dihentikan
const tugas = async () => {
  await new Promise((selesai) => {
    const t = setInterval(() => {
      if (!BackgroundService.isRunning()) { clearInterval(t); selesai(); }
    }, 30000);
  });
};

let sedangMulai = false;
export async function nyalakanLayanan() {
  if (sedangMulai) return;
  try {
    if (BackgroundService.isRunning()) return;
    sedangMulai = true;
    await BackgroundService.start(tugas, opsi);
  } catch (e) { /* dicoba lagi pada siklus mesin berikutnya */ } finally { sedangMulai = false; }
}

export async function matikanLayanan() {
  try { if (BackgroundService.isRunning()) await BackgroundService.stop(); } catch (e) {}
}

let terakhirNotif = 0;
export async function perbaruiNotifLayanan(teks) {
  try {
    if (Date.now() - terakhirNotif < 60000 || !BackgroundService.isRunning()) return;
    terakhirNotif = Date.now();
    await BackgroundService.updateNotification({ taskDesc: teks });
  } catch (e) {}
}
