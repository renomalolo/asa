// Penyimpanan konfigurasi & "gembok" (penanda kejadian yang sudah dijalankan hari ini).
// Pengganti config.json dan gembok_status.json pada versi Lua.
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KUNCI_CFG = 'jadwalsalat:config';
const KUNCI_GEMBOK = 'jadwalsalat:gembok';

export const WAKTU5 = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

export function konfigurasiAwal() {
  const c = {
    kota: 'Belum Diatur', idKota: '', lokasiDitemukan: '',
    jenisSuaraTTS: 'default', ttsSpeed: 1.0, ttsPitch: 1.0,
    master_aktif: true, lokasiOtomatis: true, lokasiCekTerakhir: 0,
    memMurottal: {}, memMurottalOn: {},
    modeMurottal: 'ikatan', lastMurottalPath: '', lastMurottalPos: 0,
    ikhtiar: 0, volAdzan: 100, volMurottal: 60,
    waktuMurottal: 30, waktuTarhim: 6, waktuIqomah: 10, waktuArham: 10,
    iqomah_on: true, durasiKhusyuk: 30,
    autoVolume: false, getarAwal: false, ttsVarian: false, deteksiOtomatis: true,
    penjagaSunyi: true, // jaga mesin tetap hidup saat layar mati (audio hening + layanan latar depan)
    alarm_waktu: '', alarm_pesan: '', koreksiHijriyah: 0,
    selisih: {}, jadwalSebulan: false, profilLokasi: {},
    s_jam: false, s_istiwa: false, s_preterbit: false, s_terbit: false, s_dhuha: false,
    s_tahajud: false, s_imsak: false, s_puasa: false, s_jumat: false, s_rawatib: false,
    s_khusyuk: false, s_kehatihatian: false, s_musafir: false,
  };
  for (const n of WAKTU5) {
    const k = n.toLowerCase();
    c['adzan_' + k + '_on'] = true;
    c['tarhim_' + k + '_on'] = true;
    c['murottal_' + k + '_on'] = true;
    c['adzan' + n + 'File'] = '';
    c['tarhim' + n + 'File'] = '';
    c.selisih[n] = 0;
  }
  return c;
}

// Objek tunggal yang dimutasi (sama seperti _G.AdzanConfig pada versi Lua)
export const cfg = konfigurasiAwal();
// Penanda kejadian: nilai true, atau string "HH:MM" untuk iqomah yang menunggu
export const gembok = {};

const pendengar = new Set();
const beri = () => pendengar.forEach((f) => { try { f(); } catch (e) {} });

export async function muatData() {
  try {
    const raw = await AsyncStorage.getItem(KUNCI_CFG);
    if (raw) {
      const d = JSON.parse(raw);
      const dasar = konfigurasiAwal();
      Object.assign(cfg, dasar, d);
      cfg.selisih = { ...dasar.selisih, ...(d.selisih || {}) };
    }
  } catch (e) {}
  try {
    const g = await AsyncStorage.getItem(KUNCI_GEMBOK);
    if (g) Object.assign(gembok, JSON.parse(g));
  } catch (e) {}
}

let antreSimpan = null;
export function simpanData() {
  beri();
  clearTimeout(antreSimpan);
  antreSimpan = setTimeout(() => {
    AsyncStorage.setItem(KUNCI_CFG, JSON.stringify(cfg)).catch(() => {});
  }, 150);
}

export function simpanGembok() {
  AsyncStorage.setItem(KUNCI_GEMBOK, JSON.stringify(gembok)).catch(() => {});
}
export function setGembok(baru) {
  for (const k of Object.keys(gembok)) delete gembok[k];
  Object.assign(gembok, baru);
  simpanGembok();
}

export async function resetPabrik() {
  const dasar = konfigurasiAwal();
  for (const k of Object.keys(cfg)) delete cfg[k];
  Object.assign(cfg, dasar);
  for (const k of Object.keys(gembok)) delete gembok[k];
  await AsyncStorage.multiRemove([KUNCI_CFG, KUNCI_GEMBOK]).catch(() => {});
  simpanData();
  simpanGembok();
}

// Hook: render ulang komponen saat konfigurasi berubah
export function useCfg() {
  const [, setN] = useState(0);
  useEffect(() => {
    const f = () => setN((n) => n + 1);
    pendengar.add(f);
    return () => pendengar.delete(f);
  }, []);
  return cfg;
}
