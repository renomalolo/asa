// Mesin audio: pencari berkas, pemutar, TTS, tarhim, murottal berantai, adzan.
// Port dari bagian audio main.lua (versi akhir setelah semua "pembungkus" digabung).
import { Platform, ToastAndroid, Vibration } from 'react-native';
import { createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import * as Speech from 'expo-speech';
import { Asset } from 'expo-asset';
import { Directory, File, Paths } from 'expo-file-system';
import { VolumeManager, RINGER_MODE } from 'react-native-volume-manager';
import { cfg, simpanData, gembok, simpanGembok, WAKTU5 } from './store';
import { S, setPlayerUI, sleep, tunda } from './state';
import {
  hitungMenitAbsolut, tambahMenit, selisihWaktu, isWaktunya, nowSec, detikHariIni, hariKe, tglIni,
} from './waktu';
import { AUDIO_BAWAAN } from './audioAssets';
import { matikanLayanan, nyalakanLayanan } from './layanan';

// ===================== FOLDER & BERKAS =====================
export const DIR_PLUGIN = new Directory(Paths.document, 'JadwalSalat');
export const DIR_MUROTTAL = new Directory(DIR_PLUGIN, 'murottal');
const EKSTENSI = /\.(mp3|ogg|m4a|wav)$/i;

export function pastikanFolder() {
  try { if (!DIR_PLUGIN.exists) DIR_PLUGIN.create(); } catch (e) {}
  try { if (!DIR_MUROTTAL.exists) DIR_MUROTTAL.create(); } catch (e) {}
}

// Salin audio bawaan (assets/audio) ke folder murottal. Hanya yang belum ada.
export async function salinAudioBawaan(lapor) {
  pastikanFolder();
  const daftar = Object.entries(AUDIO_BAWAAN);
  let i = 0;
  for (const [nama, mod] of daftar) {
    i += 1;
    try {
      const tujuan = new File(DIR_MUROTTAL, nama);
      if (tujuan.exists) continue;
      if (lapor) lapor(`Menyiapkan audio ${i}/${daftar.length}: ${nama}`);
      const a = Asset.fromModule(mod);
      await a.downloadAsync();
      const sumber = new File(a.localUri || a.uri);
      await Promise.resolve(sumber.copy(tujuan));
    } catch (e) { /* lanjut ke berkas berikutnya */ }
  }
}

export function salinBerkasKeMurottal(uriSumber, namaTujuan) {
  pastikanFolder();
  const sumber = new File(uriSumber);
  const tujuan = new File(DIR_MUROTTAL, namaTujuan);
  if (tujuan.exists) tujuan.delete();
  return Promise.resolve(sumber.copy(tujuan));
}

const namaAman = (f) => { try { return decodeURIComponent(f.name); } catch (e) { return f.name; } };
const normal = (s) => s.toLowerCase().replace(/[\s\-_]/g, '');

function daftarAudio(dir) {
  try {
    if (!dir.exists) return [];
    return dir.list().filter((x) => x instanceof File && EKSTENSI.test(x.name));
  } catch (e) { return []; }
}
const adaBerkas = (uri) => { try { return !!uri && new File(uri).exists; } catch (e) { return false; } };

const reAdzan = (n) => /adzan|azan|ajan|adhan|adzn/.test(n);
const reSubuh = (n) => /subuh|sbh|shubuh/.test(n);
const reTarhim = (n) => /tarhim|tarhiim|tahrim/.test(n);

// Cari berkas audio dari kata kunci (acak bila lebih dari satu cocok).
function radarAsli(kataKunci) {
  try {
    const kL = normal(String(kataKunci || ''));
    const semua = [...daftarAudio(DIR_PLUGIN), ...daftarAudio(DIR_MUROTTAL)];
    const cocok = [];
    for (const f of semua) {
      const nB = normal(namaAman(f));
      const isAdzan = reAdzan(nB); const isSubuh = reSubuh(nB);
      const isBumper = /bumper|pembuka|awal/.test(nB);
      const isIqomah = /iqomah|ikomah|qomat/.test(nB);
      const isTarhim = reTarhim(nB); const isArham = nB.includes('arham');
      let ok = false;
      if (kL === 'adzan') ok = isAdzan && !isSubuh;
      else if (kL === 'adzansubuh') ok = isAdzan && isSubuh;
      else if (kL === 'terbit') ok = nB.includes('terbit') && !nB.includes('peringatan');
      else if (kL === 'peringatanterbit') ok = nB.includes('peringatan') && nB.includes('terbit');
      else if (kL === 'aljumuah') ok = nB.includes('aljumuah') || nB.includes('jumuah') || nB.includes('jumat');
      else if (kL === 'yasin') ok = nB.includes('yasin') || nB.includes('yaasiin');
      else if (kL === 'sahur') ok = nB.includes('sahur');
      else if (kL === 'bumper') ok = isBumper;
      else if (kL === 'tarhim') ok = isTarhim;
      else if (kL === 'arham') ok = isArham;
      else if (kL === 'dhuha') ok = nB.includes('dhuha') || nB.includes('duha');
      else if (kL === 'tahajud') ok = nB.includes('tahajud') || nB.includes('tahajjud');
      else if (kL === 'iqomah') ok = isIqomah;
      else if (kL === '') ok = !(isAdzan || isTarhim || isArham || isBumper || nB.includes('sahur') || isIqomah || nB.includes('peringatan') || nB.includes('terbit') || nB.includes('dhuha') || nB.includes('tahajud'));
      else if (WAKTU5.map((x) => x.toLowerCase()).includes(kL)) ok = nB.includes(kL) && !isAdzan;
      else ok = nB.includes(kL);
      if (ok) cocok.push(f.uri);
    }
    const lima = WAKTU5.map((x) => x.toLowerCase());
    if (cocok.length === 0 && lima.includes(kL)) {
      for (const f of semua) {
        const nB = normal(namaAman(f));
        if ((nB.includes('murottal') || nB.includes('ngaji') || nB.includes('surat')) && !reAdzan(nB)) cocok.push(f.uri);
      }
    }
    if (cocok.length === 0 && kL === 'adzansubuh') {
      for (const f of semua) if (reAdzan(normal(namaAman(f)))) cocok.push(f.uri);
    }
    return cocok.length ? cocok[Math.floor(Math.random() * cocok.length)] : null;
  } catch (e) { return null; }
}

// Memori murottal: bila waktu salat punya berkas yang diingat, pakai itu dulu
export function radarAudioPintar(kataKunci) {
  try {
    const k = String(kataKunci || '');
    for (const n of WAKTU5) {
      if (k === n.toLowerCase()) {
        const m = cfg.memMurottal[n];
        if (m && m.path && adaBerkas(m.path)) return m.path;
      }
    }
  } catch (e) {}
  return radarAsli(kataKunci);
}

// Daftar berkas untuk pilihan di menu (adzan / tarhim / arham). Nilai = nama berkas.
export function dapatkanDaftarBerkas(jenisFilter) {
  const nama = ['[ ACAK / OTOMATIS ]']; const nilai = [''];
  const kumpul = (dir, label) => {
    for (const f of daftarAudio(dir)) {
      const nB = normal(namaAman(f));
      const cocok = (jenisFilter === 'adzan' && reAdzan(nB)) || (jenisFilter === 'tarhim' && reTarhim(nB)) || (jenisFilter === 'arham' && nB.includes('arham'));
      if (cocok) { nama.push(`${label} ${namaAman(f)}`); nilai.push(namaAman(f)); }
    }
  };
  kumpul(DIR_PLUGIN, '[ UTAMA ]'); kumpul(DIR_MUROTTAL, '[ FOLDER MUROTTAL ]');
  return { nama, nilai };
}

// Daftar murottal (menyapu subfolder, maks 4 tingkat) -> nilai = URI lengkap
export function dapatkanDaftarMurottal() {
  const nama = ['[ ACAK / OTOMATIS ]']; const nilai = [''];
  const sudah = new Set(); const hasil = [];
  const sapu = (dir, akar, tingkat) => {
    if (tingkat > 4 || hasil.length >= 500) return;
    let isi = [];
    try { isi = dir.list(); } catch (e) { return; }
    for (const v of isi) {
      if (v instanceof Directory) sapu(v, akar, tingkat + 1);
      else if (v instanceof File && EKSTENSI.test(v.name) && !sudah.has(v.uri)) {
        sudah.add(v.uri);
        hasil.push({ path: v.uri, label: decodeURIComponent(v.uri.slice(akar.length)).replace(/^\/+/, '') });
      }
    }
  };
  for (const d of [DIR_MUROTTAL, DIR_PLUGIN]) { try { if (d.exists) sapu(d, d.uri, 1); } catch (e) {} }
  hasil.sort((a, b) => a.label.toLowerCase().localeCompare(b.label.toLowerCase()));
  for (const h of hasil) { nama.push(h.label); nilai.push(h.path); }
  return { nama, nilai };
}

export function cariBerkasPilihan(namaBerkas) {
  if (!namaBerkas) return null;
  for (const d of [DIR_MUROTTAL, DIR_PLUGIN]) {
    const f = new File(d, namaBerkas);
    if (f.exists) return f.uri;
  }
  return null;
}

// ===================== INFO & GETAR =====================
export function infoVisual(teks) {
  if (Platform.OS === 'android') ToastAndroid.show(String(teks), ToastAndroid.SHORT);
}
export const getar = (ms = 300) => { try { Vibration.vibrate(ms); } catch (e) {} };

// ===================== MODE AUDIO =====================
export async function siapkanModeAudio() {
  try {
    await setAudioModeAsync({
      playsInSilentMode: true,
      shouldPlayInBackground: true,
      interruptionMode: 'doNotMix',
    });
  } catch (e) {}
}

// ===================== PENJAGA SUNYI (jaga mesin tetap hidup) =====================
const le32 = (v) => [v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];
const le16 = (v) => [v & 255, (v >> 8) & 255];
function bytesHening() {
  const n = 16000; // 2 detik, 8000 Hz, mono, 8 bit
  const b = new Uint8Array(44 + n);
  const kepala = [
    ...[82, 73, 70, 70], ...le32(36 + n), ...[87, 65, 86, 69], ...[102, 109, 116, 32], ...le32(16),
    ...le16(1), ...le16(1), ...le32(8000), ...le32(8000), ...le16(1), ...le16(8), ...[100, 97, 116, 97], ...le32(n),
  ];
  b.set(kepala, 0); b.fill(128, 44);
  return b;
}

let pHening = null;
export function nyalakanPenjagaSunyi() {
  try {
    if (pHening) { try { if (pHening.playing) return; } catch (e) {} }
    if (sedangMain()) return; // pemutar utama sudah menahan layanan latar depan
    pastikanFolder();
    const f = new File(Paths.document, 'hening.wav'); // di luar folder yang dipindai radar audio
    if (!f.exists || f.size < 100) { if (!f.exists) f.create(); f.write(bytesHening()); }
    if (pHening) { try { pHening.release(); } catch (e) {} pHening = null; }
    const p = createAudioPlayer({ uri: f.uri });
    p.loop = true; p.volume = 1;
    p.play();
    try { p.setActiveForLockScreen(true, { title: 'Jadwal Salat by Reno', artist: 'Mesin jadwal aktif' }); } catch (e) {}
    pHening = p;
  } catch (e) {}
}
export function matikanPenjagaSunyi() {
  try { if (pHening) { try { pHening.pause(); } catch (e) {} pHening.release(); } } catch (e) {}
  pHening = null;
}
// Selama MASTER aktif: layanan latar depan menjaga timer JS tetap berjalan; audio hening (opsional)
// menjaga CPU tetap terjaga. Saat MASTER mati, keduanya dilepas.
export function jagaMesinTetapHidup() {
  try {
    if (cfg.master_aktif) {
      nyalakanLayanan();
      if (cfg.penjagaSunyi) nyalakanPenjagaSunyi(); else matikanPenjagaSunyi();
    } else {
      matikanPenjagaSunyi();
      matikanLayanan();
    }
  } catch (e) {}
}

// ===================== VOLUME & MODE KHUSYUK =====================
export async function eksekusiAutoVolume(setelah) {
  if (!cfg.autoVolume) { if (setelah) setelah(); return; }
  try {
    const r = await VolumeManager.getVolume();
    const cur = typeof r === 'number' ? r : (r && (r.volume ?? r.music)) ?? 0;
    S.volumeLama = cur;
    if (cur < 0.7) await VolumeManager.setVolume(0.85, { showUI: false });
  } catch (e) {}
  if (setelah) setelah();
}
export function kembalikanVolume() {
  if (!cfg.autoVolume || S.volumeLama == null) return;
  try { VolumeManager.setVolume(S.volumeLama, { showUI: false }); } catch (e) {}
  S.volumeLama = null;
}
export async function eksekusiModeKhusyuk(durasiMenit, namaWaktu) {
  if (!cfg.s_khusyuk) return;
  try {
    if (VolumeManager.getRingerMode && VolumeManager.setRingerMode) {
      S.ringerLama = await VolumeManager.getRingerMode();
      await VolumeManager.setRingerMode(RINGER_MODE.vibrate);
    }
    bicaraGoogleTTS(`Memasuki waktu ${namaWaktu}. Mode khusyuk diaktifkan.`, true);
    tunda(durasiMenit * 60000, async () => {
      try {
        await VolumeManager.setRingerMode(S.ringerLama != null ? S.ringerLama : RINGER_MODE.normal);
        S.ringerLama = null;
        bicaraGoogleTTS('Mode khusyuk telah berakhir.', true);
      } catch (e) {}
    });
  } catch (e) {}
}

// ===================== TTS =====================
export function dapatkanTeksVarian(jenis, param) {
  if (!cfg.ttsVarian) {
    const t = {
      Tarhim: 'Waktu sholat akan segera tiba. Bersiaplah dengan wudhu dan doa.',
      Iqomah: 'Waktu jeda iqomah telah usai. Bersiaplah untuk mendirikan sholat.',
      Imsak: 'Waktu Imsak telah tiba. Segera selesaikan sahur Anda.',
      Istiwa: 'Waktu istiwa telah masuk. Diharamkan mendirikan sholat hingga adzan Dzuhur.',
      Tahajud: 'Sepertiga malam terakhir telah tiba. Bangunlah untuk sholat Tahajud.',
      Jumat: 'Hari Jumat. Jangan lupa membaca Al-Kahfi dan mandi sunnah.',
      Kehati: `Peringatan kehati-hatian. Waktu sholat ${param || ''} tersisa lima belas menit lagi.`,
    };
    return t[jenis] || '';
  }
  const pool = {
    Subuh: ['Waktu Subuh telah tiba. Sholatlah sebelum matahari terbit.', 'Subuh berkumandang. Bangunlah dari tidurmu.'],
    Dzuhur: ['Waktu Dzuhur telah tiba. Istirahatkan dirimu sejenak untuk menghadap Allah.', 'Dzuhur datang. Tinggalkan sejenak urusan dunia.'],
    Ashar: ['Waktu Ashar telah tiba. Bersegeralah sebelum matahari menguning.', 'Ashar memanggil. Jangan tunda lagi.'],
    Maghrib: ['Waktu Maghrib telah tiba. Bagi yang berpuasa, inilah saatnya berbuka.', 'Saat matahari tenggelam, saat itulah Maghrib berkumandang.'],
    Isya: ['Waktu Isya telah tiba. Akhiri harimu dengan sujud kepada Allah.', 'Jangan tidur sebelum Isya. Dirikanlah sholat sebagai benteng.'],
    Dhuha: ['Waktu sholat Dhuha telah masuk.'],
    Tahajud: ['Sepertiga malam terakhir telah tiba. Bangunlah untuk sholat Tahajud.'],
    Imsak: ['Waktu Imsak telah tiba. Segera selesaikan sahur.'],
    Istiwa: ['Waktu istiwa telah masuk. Diharamkan mendirikan sholat hingga adzan Dzuhur.'],
    Jumat: ['Hari ini adalah Jumat. Bacalah Al-Kahfi, perbanyak shalawat, dan bersegeralah ke masjid.'],
    Tarhim: ['Waktu sholat akan segera tiba. Bersiaplah dengan wudhu dan doa.', 'Persiapkan diri Anda, panggilan sholat segera bergema.'],
    Iqomah: ['Iqomah telah dikumandangkan. Sholat akan segera dimulai.', 'Waktu jeda usai, mari luruskan shaf.'],
    Kehati: [`Peringatan kehati-hatian. Waktu sholat ${param || ''} tersisa lima belas menit lagi.`],
  };
  const p = pool[jenis];
  return p ? p[Math.floor(Math.random() * p.length)] : '';
}

export async function daftarSuaraID() {
  try {
    const v = await Speech.getAvailableVoicesAsync();
    return v.filter((x) => String(x.language || '').toLowerCase().startsWith('id'));
  } catch (e) { return []; }
}

export function bicaraGoogleTTS(teks, senyapVisual, callback) {
  try {
    teks = String(teks || '');
    if (!senyapVisual && Platform.OS === 'android') ToastAndroid.show(teks, ToastAndroid.LONG);
    let ducking = false;
    if (sedangMain()) { ducking = true; try { mp.player.volume = 0.1; } catch (e) {} }
    let selesai = false; let pengaman = null;
    const fin = () => {
      if (selesai) return; selesai = true; clearTimeout(pengaman);
      if (ducking && sedangMain()) { try { mp.player.volume = (S.volTerakhirDiputar || 60) / 100; } catch (e) {} }
      if (callback) { try { callback(); } catch (e) {} }
    };
    pengaman = setTimeout(fin, Math.max(2500, teks.length * 100) + 8000); // cadangan bila onDone tak datang
    const opsi = { language: 'id-ID', rate: Number(cfg.ttsSpeed) || 1, pitch: Number(cfg.ttsPitch) || 1, onDone: fin, onStopped: fin, onError: fin };
    if (cfg.jenisSuaraTTS && cfg.jenisSuaraTTS !== 'default') opsi.voice = cfg.jenisSuaraTTS;
    Speech.speak(teks, opsi);
  } catch (e) { if (callback) { try { callback(); } catch (e2) {} } }
}

// ===================== PEMUTAR =====================
let mp = null;          // { player, sub, selesai, path }
let aksiSelesai = null; // callback setelah audio selesai alami

export function sedangMain() {
  try { return !!mp && !mp.selesai && mp.player.playing === true; } catch (e) { return false; }
}
export const posisiMs = () => { try { return mp.player.currentTime * 1000; } catch (e) { return 0; } };

function bersihkanMediaPlayer() {
  if (!mp) return;
  const lama = mp; mp = null;
  try { lama.sub && lama.sub.remove(); } catch (e) {}
  try { lama.player.pause(); } catch (e) {}
  try { lama.player.release(); } catch (e) {}
  jagaMesinTetapHidup();
}

function hentikanAsli() {
  try {
    if (sedangMain()) {
      if (cfg.modeMurottal === 'sambung' && !S.sedangPutarSpesial) {
        cfg.lastMurottalPos = Math.floor(posisiMs()); simpanData();
      }
      const lama = mp; mp = null;
      try { lama.sub && lama.sub.remove(); } catch (e) {}
      let vol = (S.volTerakhirDiputar || 60) / 100; const langkah = vol / 10;
      const fade = () => {
        let main = false;
        try { main = lama.player.playing; } catch (e) {}
        if (main && vol > 0.05) {
          vol -= langkah;
          try { lama.player.volume = Math.max(vol, 0); } catch (e) {}
          tunda(150, fade);
        } else {
          try { lama.player.pause(); } catch (e) {}
          try { lama.player.release(); } catch (e) {}
          jagaMesinTetapHidup();
        }
      };
      fade();
    } else bersihkanMediaPlayer();
  } catch (e) {}
  setPlayerUI({ aktif: false, judul: '' });
}

// Berhenti + simpan menit terakhir murottal + sambung otomatis murottal -> tarhim
export function hentikanAudioDanSimpan() {
  try {
    const main = sedangMain();
    const mm = S.murottalMem;
    if (mm) {
      if (main) {
        const pos = posisiMs(); let dur = 0;
        try { dur = mp.player.duration * 1000; } catch (e) {}
        cfg.memMurottal[mm.waktu] = (dur > 0 && pos >= dur - 3000) ? { path: '', pos: 0 } : { path: mm.path, pos: Math.floor(pos) };
        S.murottalMem = null; simpanData();
      } else if (nowSec() - mm.t > 8) {
        cfg.memMurottal[mm.waktu] = { path: '', pos: 0 };
        S.murottalMem = null; simpanData();
      }
    }
    const mr = S.murottalRantai;
    if (mr) {
      if (main) S.murottalRantai = null; // dihentikan paksa / diganti audio lain: tidak disambung
      else if (nowSec() - mr.t > 8) { // murottal tamat sendiri
        S.murottalRantai = null;
        const w = mr.waktu;
        tunda(200, () => rantaiTarhim(w));
      }
    }
  } catch (e) {}
  return hentikanAsli();
}

function mulaiPemutar(path, judul, jenis, { posisiDetik = 0, onSelesai = null } = {}) {
  const volP = jenis === 'adzan' ? (cfg.volAdzan || 100) : (cfg.volMurottal || 60);
  S.volTerakhirDiputar = volP;
  setPlayerUI({ aktif: true, judul });
  bersihkanMediaPlayer();
  aksiSelesai = onSelesai;
  try {
    const player = createAudioPlayer({ uri: path });
    const obj = { player, sub: null, selesai: false, path };
    obj.sub = player.addListener('playbackStatusUpdate', (st) => {
      if (st && st.didJustFinish && mp === obj) {
        obj.selesai = true;
        const aksi = aksiSelesai; aksiSelesai = null;
        if (aksi) { try { aksi(); } catch (e) {} }
        if (mp === obj) hentikanAudioDanSimpan(); // jangan matikan audio baru yang dimulai callback
      }
    });
    player.volume = volP / 100;
    mp = obj;
    if (posisiDetik > 0) { try { player.seekTo(posisiDetik); } catch (e) {} }
    player.play();
    try { player.setActiveForLockScreen(true, { title: judul, artist: 'Jadwal Salat by Reno' }); } catch (e) {}
  } catch (e) {
    setPlayerUI({ aktif: false, judul: '' });
  }
}

export function putarAudioFileLangsung(path, judul, jenis, callbackSelesai) {
  try {
    hentikanAudioDanSimpan();
    S.sedangPutarSpesial = false;
    mulaiPemutar(path, judul, jenis, { onSelesai: callbackSelesai });
  } catch (e) {}
}

export function putarAudioDenganCallback(jenis, param, callbackSelesai) {
  try {
    hentikanAudioDanSimpan();
    const path = radarAudioPintar(normal(String(param || '')));
    if (!path) { if (callbackSelesai) callbackSelesai(); return; }
    mulaiPemutar(path, param, jenis, { onSelesai: callbackSelesai });
  } catch (e) {}
}

export function waktuMemori(jenis, param) {
  if (jenis !== 'murottal') return null;
  const k = normal(String(param || ''));
  for (const n of WAKTU5) {
    if (k === n.toLowerCase()) {
      if (hariKe() === 4 && (n === 'Maghrib' || n === 'Isya')) return null; // malam Jumat: Yasin
      return n;
    }
  }
  return null;
}

// Memutar audio: jenis 'adzan' | 'murottal' | 'sistem'. Mengembalikan path yang dipakai.
function putarAsli(jenis, param, pathPaksa, memori) {
  let pathTarget = null; let posisi = 0;
  let judul = param === '' ? 'Murottal Acak' : param;
  let kunci = normal(String(param || ''));

  if (jenis === 'adzan') {
    const nf = cfg['adzan' + param + 'File'] || '';
    pathTarget = nf ? cariBerkasPilihan(nf) : null;
    if (!pathTarget) kunci = param === 'Subuh' ? 'adzansubuh' : 'adzan';
    judul = 'Adzan ' + param;
  } else if (jenis === 'murottal') {
    if (kunci === 'aljumuah') { judul = "Murottal Al-Jumu'ah"; S.sedangPutarSpesial = true; }
    else if (WAKTU5.map((x) => x.toLowerCase()).includes(kunci)) {
      if (hariKe() === 4 && (kunci === 'maghrib' || kunci === 'isya')) { kunci = 'yasin'; judul = 'Murottal Yasin'; S.sedangPutarSpesial = true; }
    }
  }
  if (!pathTarget) pathTarget = pathPaksa || radarAudioPintar(kunci);

  if (memori && jenis === 'murottal' && !S.sedangPutarSpesial && pathTarget) {
    posisi = memori.path === pathTarget ? (memori.pos || 0) : 0;
  } else if (cfg.modeMurottal === 'sambung' && jenis === 'murottal' && !S.sedangPutarSpesial && pathTarget) {
    if (cfg.lastMurottalPath === pathTarget) posisi = cfg.lastMurottalPos || 0;
    else { cfg.lastMurottalPath = pathTarget; posisi = 0; }
  }
  if (!pathTarget) { bicaraGoogleTTS('Berkas audio tidak ditemukan.', true); return null; }

  mulaiPemutar(pathTarget, judul, jenis, {
    posisiDetik: posisi / 1000,
    onSelesai: () => {
      if (jenis === 'adzan' && cfg.s_rawatib) bicaraGoogleTTS('Panggilan adzan telah usai. Dirikanlah sholat sunnah rawatib sebelum iqomah dikumandangkan.', true);
    },
  });
  return pathTarget;
}

export async function putarAudio(jenis, param = '', pathPaksa = null) {
  if (await tundaMurottalPas(jenis, param, pathPaksa)) return;
  try { hentikanAudioDanSimpan(); } catch (e) {} // simpan memori audio yang sedang jalan lebih dulu
  S.sedangPutarSpesial = false;
  if (jenis === 'murottal') {
    const kk = String(param || '').toLowerCase();
    for (const n of WAKTU5) if (kk === n.toLowerCase()) S.murottalRantai = { waktu: n, t: nowSec() };
  }
  const w = waktuMemori(jenis, param);
  if (!w) { S.murottalMem = null; putarAsli(jenis, param, pathPaksa, null); return; }
  const m = cfg.memMurottal[w];
  const dipakai = putarAsli(jenis, param, pathPaksa, { path: (m && m.path) || '', pos: (m && m.pos) || 0 });
  S.murottalMem = dipakai && adaBerkas(dipakai) ? { waktu: w, path: dipakai, t: nowSec() } : null;
}

// ===================== TARHIM & MUROTTAL (durasi, cadangan, rantai) =====================
export const tarhimOto = () => cfg.waktuTarhim === 0 || (cfg.deteksiOtomatis && cfg.waktuTarhim > 0);
export const murottalOto = () => cfg.waktuMurottal === -1 || (cfg.deteksiOtomatis && cfg.waktuMurottal > 0);

export async function durasiFileMs(path) {
  if (!path) return 0;
  const c = S.cacheDurasi[path]; if (c) return c;
  let d = 0; let p = null;
  try {
    p = createAudioPlayer({ uri: path }); p.volume = 0;
    for (let i = 0; i < 30; i++) {
      if (p.isLoaded && p.duration > 0) { d = Math.round(p.duration * 1000); break; }
      await sleep(150);
    }
  } catch (e) {}
  try { p && p.release(); } catch (e) {}
  if (d > 0) S.cacheDurasi[path] = d;
  return d;
}

export async function pilihBerkas(kataKunci, tgl, nama) {
  const kunci = `${kataKunci}|${nama}|${tgl}`;
  const c = S.cachePilih[kunci]; if (c !== undefined) return c || null;
  const ap = radarAudioPintar(kataKunci);
  S.cachePilih[kunci] = ap || false;
  return ap;
}

// Pilih tarhim sekali per waktu salat per hari, lalu ukur durasi aslinya
export async function siapkanTarhim(nama, tgl) {
  const kunci = nama + tgl;
  let info = S.cacheTarhim[kunci];
  if (info === undefined) {
    const khusus = cariBerkasPilihan(cfg['tarhim' + nama + 'File'] || '');
    const ap = khusus || radarAudioPintar('tarhim');
    if (!ap) { S.cacheTarhim[kunci] = false; return null; }
    const teks = dapatkanTeksVarian('Tarhim');
    let durMs = await durasiFileMs(ap);
    if (!durMs || durMs <= 0) durMs = 6 * 60000;
    const tts = Math.max(2.5, teks.length * 0.1);
    info = { ap, teks, durMs, lead: Math.ceil(durMs / 1000 + 1.7 + tts + 1.5 + 6) };
    S.cacheTarhim[kunci] = info;
  }
  if (info === false) return null;
  // mode otomatis: potong cadangan agar tarhim selesai pas di waktu adzan
  if (!info.dipangkas && tarhimOto()) {
    info.dipangkas = true;
    const tts = Math.max(2.5, (info.teks || '').length * 0.1);
    info.lead = Math.ceil((info.durMs || 0) / 1000 + 0.5 + tts + 3);
  }
  return info;
}

export function saatnyaTarhim(wStr, info) {
  if (tarhimOto()) {
    if (!info) return false;
    const tm = hitungMenitAbsolut(wStr); if (tm === -1) return false;
    const sisa = (tm * 60 - detikHariIni() + 86400) % 86400;
    return sisa <= info.lead && sisa >= 30;
  }
  return isWaktunya(tambahMenit(wStr, -cfg.waktuTarhim));
}

export async function siapkanMurottal(nama, tgl, isJumatDzuhur) {
  const kunci = nama + tgl;
  const c = S.cacheMurottal[kunci]; if (c !== undefined) return c || null;
  let tKunci = nama.toLowerCase(); let spesial = false;
  if (isJumatDzuhur) { tKunci = 'aljumuah'; spesial = true; }
  else if (hariKe() === 4 && (tKunci === 'maghrib' || tKunci === 'isya')) { tKunci = 'yasin'; spesial = true; }
  const ap = radarAudioPintar(tKunci);
  if (!ap) { S.cacheMurottal[kunci] = false; return null; }
  const info = { ap, durMs: await durasiFileMs(ap), spesial };
  S.cacheMurottal[kunci] = info;
  return info;
}

// Sisa murottal yang akan diputar (ikut menit yang diingat)
export function sisaMurottalMs(info) {
  let ms = null;
  try {
    if (info && info.ap && !info.spesial) {
      for (const n of WAKTU5) {
        const m = cfg.memMurottal[n];
        if (m && m.path === info.ap && (m.pos || 0) > 0) { ms = Math.max((info.durMs || 0) - m.pos, 0); break; }
      }
    }
  } catch (e) {}
  if (ms === null) {
    let sisa = info.durMs || 0;
    if (cfg.modeMurottal === 'sambung' && !info.spesial && cfg.lastMurottalPath === info.ap) sisa -= cfg.lastMurottalPos || 0;
    ms = Math.max(sisa, 0);
  }
  if (ms > 10000 && info && !info.spesial && murottalOto() && tarhimOto()) ms -= 7000;
  return ms;
}

export function susunTeksAwal(nama) {
  const sMusafir = cfg.s_musafir ? '. Mode Musafir aktif, Anda berhak sholat jamak dan qashar.' : '';
  const sRamadhan = (S.bulanHijriyahIni === 'Ramadhan' && nama === 'Isya') ? '. Mari bersiap untuk Tarawih dan Witir.' : '';
  return `Waktu sholat ${nama} akan segera tiba${sMusafir}${sRamadhan}`;
}

// Detik menuju adzan berikutnya untuk waktu n; null bila jadwal belum ada
export function sisaKeAdzan(n) {
  const tgl = tglIni();
  const jdw = cfg.jadwalSebulan && typeof cfg.jadwalSebulan === 'object' ? cfg.jadwalSebulan[tgl] : null;
  if (!jdw || !jdw[n]) return null;
  const wStr = tambahMenit(jdw[n], selisihWaktu(n));
  const tm = hitungMenitAbsolut(wStr); if (tm === -1) return null;
  return { sisa: (tm * 60 - detikHariIni() + 86400) % 86400, wStr, tgl };
}

export const leadTarhimPas = (info) => (info.durMs || 0) / 1000 + 0.5 + Math.max(2.5, (info.teks || '').length * 0.1);

// Murottal otomatis: bila mulai terlalu awal, tunda sebentar SEBELUM murottal
async function tundaMurottalPas(jenis, param, pathPaksa) {
  if (jenis !== 'murottal' || S.slackLewat) return false;
  try {
    if (!(cfg.master_aktif && murottalOto() && tarhimOto())) return false;
    const kk = String(param || '').toLowerCase();
    const n = WAKTU5.find((x) => x.toLowerCase() === kk);
    if (!n || !cfg['tarhim_' + kk + '_on']) return false;
    const r = sisaKeAdzan(n); if (!r) return false;
    const path = pathPaksa || radarAudioPintar(kk); if (!path) return false;
    const durMs = await durasiFileMs(path); if (!durMs || durMs <= 0) return false;
    const m = cfg.memMurottal[n]; const pos = m && m.path === path ? (m.pos || 0) : 0;
    const info = await siapkanTarhim(n, r.tgl); if (!info) return false;
    const slack = r.sisa - ((durMs - pos) / 1000 + leadTarhimPas(info));
    if (slack > 1.5 && slack <= 60) {
      tunda(slack * 1000, async () => {
        S.slackLewat = true;
        try { await putarAudio(jenis, param, pathPaksa); } finally { S.slackLewat = false; }
      });
      return true;
    }
  } catch (e) {}
  return false;
}

// Urutan: murottal dihentikan halus -> TTS pembuka -> tarhim -> (rantai) adzan
export async function jalankanTarhim(ap, judul, teks) {
  S.tarhimBerjalan = true; S.tarhimMulai = nowSec();
  const oto = tarhimOto();
  const murJalan = sedangMain();
  const m = String(judul || '').match(/^Tarhim\s+(\S+)/);
  const n = m ? m[1] : null;
  let tambah = 0;
  if (oto && !murJalan && n && WAKTU5.includes(n)) {
    try {
      const r = sisaKeAdzan(n);
      const info = await siapkanTarhim(n, tglIni());
      if (r && info) {
        const slack = r.sisa - leadTarhimPas(info);
        if (slack > 1.5 && slack <= 60) tambah = Math.floor(slack * 1000);
      }
    } catch (e) {}
  }
  hentikanAudioDanSimpan();
  const jeda1 = oto && !murJalan ? 300 : 1700;
  const jeda2 = oto ? 200 : 1500;
  tunda(jeda1 + tambah, () => {
    bicaraGoogleTTS(teks || dapatkanTeksVarian('Tarhim'), true, () => {
      tunda(jeda2, () => {
        putarAudioFileLangsung(ap, judul, 'sistem', () => {
          S.tarhimBerjalan = false;
          if (oto && n && WAKTU5.includes(n)) tunda(50, () => rantaiAdzan(n));
        });
      });
    });
  });
}

export async function rantaiTarhim(n) {
  if (!(cfg.master_aktif && murottalOto() && tarhimOto())) return;
  if (!cfg['tarhim_' + n.toLowerCase() + '_on']) return;
  if (n === 'Dzuhur' && cfg.s_jumat && hariKe() === 5) return;
  const r = sisaKeAdzan(n); if (!r) return;
  const info = await siapkanTarhim(n, r.tgl); if (!info) return;
  if (r.sisa > info.lead + 25 || r.sisa < 30) return;
  const kunci = 'TARHIM_' + n + r.tgl;
  if (gembok[kunci]) return;
  gembok[kunci] = true; simpanGembok();
  jalankanTarhim(info.ap, 'Tarhim ' + n, info.teks);
}

// Adzan tetap mengikuti jadwal: mulai tepat di jam adzan
export function rantaiAdzan(n) {
  if (!(cfg.master_aktif && tarhimOto())) return;
  if (!cfg['adzan_' + n.toLowerCase() + '_on']) return;
  if (n === 'Dzuhur' && cfg.s_jumat && hariKe() === 5) return;
  const r = sisaKeAdzan(n); if (!r) return;
  const telat = r.sisa > 86000 ? 86400 - r.sisa : null; // tarhim selesai sedikit lewat jadwal
  if (telat === null && r.sisa > 8) return;               // terlalu jauh: serahkan ke jadwal biasa
  const kunci = 'ADZ_' + n + r.tgl;
  if (gembok[kunci]) return;
  if (telat !== null && telat > 20) return;
  gembok[kunci] = true; simpanGembok();
  const tunggu = telat !== null ? 0 : Math.max(0, Math.floor(r.sisa * 1000) - 450);
  tunda(tunggu, () => {
    hentikanAudioDanSimpan(); eksekusiModeKhusyuk(cfg.durasiKhusyuk, n);
    eksekusiAutoVolume(() => tunda(400, () => { putarAudio('adzan', n); kembalikanVolume(); }));
  });
  if (cfg.iqomah_on) { gembok['IQOMAH_' + n + r.tgl] = tambahMenit(r.wStr, cfg.waktuIqomah); simpanGembok(); }
}
