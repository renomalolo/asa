// Komponen UI bersama. Warna & tata letak mengikuti versi Android Lua (tombol penuh, teks besar).
import React, { useState } from 'react';
import {
  FlatList, Modal, Pressable, ScrollView, StatusBar, StyleSheet, Text, TextInput, View,
} from 'react-native';

export const WARNA = {
  merah: '#D32F2F', hijau: '#4CAF50', abu: '#9E9E9E', biru: '#2196F3', oranye: '#FF9800',
  toska: '#009688', ungu: '#673AB7', coklat: '#795548', pink: '#E91E63', abuTua: '#616161', blueJudul: '#0000FF',
};

export function Layar({ judul, onBack, children }) {
  return (
    <View style={s.layar}>
      <Text style={s.judulApp} accessibilityRole="header">{judul}</Text>
      <ScrollView contentContainerStyle={s.isi} keyboardShouldPersistTaps="handled">
        {onBack ? <Tombol teks="KEMBALI KE MENU SEBELUMNYA" warna={WARNA.merah} onPress={onBack} /> : null}
        {children}
        {onBack ? <Tombol teks="KEMBALI KE MENU SEBELUMNYA" warna={WARNA.merah} onPress={onBack} /> : null}
      </ScrollView>
    </View>
  );
}

export function Tombol({ teks, onPress, warna = WARNA.biru, kecil = false, style }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={teks}
      style={({ pressed }) => [s.tombol, { backgroundColor: warna, opacity: pressed ? 0.8 : 1 }, kecil && s.tombolKecil, style]}
    >
      <Text style={s.teksTombol}>{teks}</Text>
    </Pressable>
  );
}

export function Toggle({ teks, nilai, onPress }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="switch"
      accessibilityLabel={teks}
      accessibilityState={{ checked: !!nilai }}
      style={[s.tombol, { backgroundColor: nilai ? WARNA.hijau : WARNA.abu }]}
    >
      <Text style={s.teksTombol}>{(nilai ? '[ ON ] ' : '[ OFF ] ') + teks}</Text>
    </Pressable>
  );
}

export const Judul = ({ teks }) => <Text style={s.judul} accessibilityRole="header">{teks}</Text>;
export const Teks = ({ teks, kecil, warna, tengah, besar }) => (
  <Text selectable style={[s.teks, kecil && { fontSize: 13 }, besar && { fontSize: 20 }, warna && { color: warna }, tengah && { textAlign: 'center' }]}>{teks}</Text>
);

// Deretan pilihan (menggantikan baris tombol horizontal): satu terpilih
export function Pilihan({ judul, opsi, nilai, onPilih }) {
  return (
    <View>
      {judul ? <Judul teks={judul} /> : null}
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {opsi.map((o) => {
          const aktif = o.nilai === nilai;
          return (
            <Pressable
              key={String(o.nilai)} onPress={() => onPilih(o.nilai)} accessibilityRole="radio"
              accessibilityLabel={o.label} accessibilityState={{ selected: aktif }}
              style={[s.chip, aktif && { backgroundColor: WARNA.hijau }]}
            >
              <Text style={[s.teksTombol, !aktif && { color: '#000' }]}>{o.label}</Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

// Pengganti Spinner Android: tombol yang membuka daftar pilihan
export function PilihList({ judul, daftar, indeks, onPilih }) {
  const [buka, setBuka] = useState(false);
  return (
    <View style={{ marginVertical: 6 }}>
      {judul ? <Text style={s.teks}>{judul}</Text> : null}
      <Pressable onPress={() => setBuka(true)} accessibilityRole="button" accessibilityLabel={`${judul || ''} ${daftar[indeks] || ''}`} style={s.kotakPilih}>
        <Text style={s.teks} numberOfLines={2}>{daftar[indeks] || '-'}</Text>
      </Pressable>
      <Modal visible={buka} animationType="slide" onRequestClose={() => setBuka(false)}>
        <View style={[s.layar, { paddingTop: (StatusBar.currentHeight || 24) + 8 }]}>
          <Tombol teks="TUTUP" warna={WARNA.merah} onPress={() => setBuka(false)} style={{ marginHorizontal: 16 }} />
          <FlatList
            data={daftar} keyExtractor={(x, i) => String(i)}
            renderItem={({ item, index }) => (
              <Pressable
                onPress={() => { onPilih(index); setBuka(false); }} accessibilityRole="button"
                style={[s.baris, index === indeks && { backgroundColor: '#E8F5E9' }]}
              >
                <Text style={s.teks}>{(index === indeks ? '[ TERPILIH ] ' : '') + item}</Text>
              </Pressable>
            )}
          />
        </View>
      </Modal>
    </View>
  );
}

export function Masukan({ judul, nilai, onUbah, placeholder, keyboardType }) {
  return (
    <View style={{ marginVertical: 6 }}>
      {judul ? <Judul teks={judul} /> : null}
      <TextInput
        value={nilai} onChangeText={onUbah} placeholder={placeholder} keyboardType={keyboardType}
        accessibilityLabel={judul} style={s.input} placeholderTextColor="#999"
      />
    </View>
  );
}

export const s = StyleSheet.create({
  layar: { flex: 1, backgroundColor: '#FFFFFF', paddingTop: StatusBar.currentHeight || 24 },
  judulApp: { fontSize: 20, color: '#000', paddingHorizontal: 20, paddingVertical: 12, fontWeight: '600' },
  isi: { padding: 16, paddingBottom: 90 },
  tombol: { paddingVertical: 14, paddingHorizontal: 14, marginVertical: 5, borderRadius: 4 },
  tombolKecil: { paddingVertical: 10 },
  teksTombol: { color: '#FFFFFF', fontSize: 15 },
  judul: { color: WARNA.blueJudul, fontSize: 15, marginTop: 24, marginBottom: 8 },
  teks: { color: '#000', fontSize: 15, marginVertical: 3 },
  chip: { backgroundColor: '#E0E0E0', paddingVertical: 12, paddingHorizontal: 14, marginRight: 6, marginVertical: 4, borderRadius: 4 },
  kotakPilih: { borderWidth: 1, borderColor: '#999', borderRadius: 4, padding: 12, marginTop: 4 },
  baris: { paddingVertical: 16, paddingHorizontal: 20, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: '#CCC' },
  input: { borderWidth: 1, borderColor: '#999', borderRadius: 4, padding: 10, fontSize: 16, color: '#000' },
});
