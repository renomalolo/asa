// Menu fitur lanjutan & info
import React from 'react';
import { Judul, Layar, Tombol } from '../ui';

export default function Fitur({ nav }) {
  const b = (t, ke) => <Tombol key={t} teks={t} onPress={() => nav.ke(ke)} />;
  return (
    <Layar judul="Fitur Lanjutan & Info" onBack={nav.awal}>
      <Judul teks="ALAT BANTU IBADAH:" />
      {b('1. RADAR KIBLAT SUARA', 'Kiblat')}
      {b('2. KALENDER HIJRIYAH (BISA DIKOREKSI)', 'Hijriyah')}
      {b('3. KALENDER JAWA', 'Jawa')}
      {b('4. JADWAL HARIAN LENGKAP', 'JadwalHarian')}
      {b('5. SETEL ALARM PRIBADI', 'Alarm')}
      <Judul teks="PENGATURAN MESIN & SUARA:" />
      {b('6. SAKELAR IBADAH LAINNYA', 'Sunnah')}
      {b('7. AUDIO & VOLUME', 'AudioVolume')}
      {b('8. DURASI WAKTU JEDA', 'Durasi')}
      {b('9. PENGATURAN CERDAS', 'Cerdas')}
      {b('10. PILIHAN SUARA TTS', 'SuaraTTS')}
      <Judul teks="SISTEM & PEMELIHARAAN:" />
      {b('11. TES AUDIO TERPADU', 'TesAudio')}
      {b('12. PROFIL LOKASI TERSIMPAN', 'Profil')}
      {b('13. DIAGNOSTIK MESIN', 'Diagnostik')}
      {b('14. PANDUAN PENGGUNAAN', 'Panduan')}
      {b('15. TENTANG APLIKASI', 'Tentang')}
    </Layar>
  );
}
