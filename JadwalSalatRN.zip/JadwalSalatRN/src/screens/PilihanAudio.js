// Pengaturan Adzan & Tarhim, serta Memori Murottal
import React, { useMemo, useState } from 'react';
import * as DocumentPicker from 'expo-document-picker';
import { Judul, Layar, PilihList, Tombol, Toggle, WARNA } from '../ui';
import { cfg, simpanData, useCfg, WAKTU5 } from '../store';
import { dapatkanDaftarBerkas, dapatkanDaftarMurottal, infoVisual, salinBerkasKeMurottal } from '../audio';

export function AdzanTarhim({ nav }) {
  const c = useCfg();
  const adzan = useMemo(() => dapatkanDaftarBerkas('adzan'), []);
  const tarhim = useMemo(() => dapatkanDaftarBerkas('tarhim'), []);
  const [sel, setSel] = useState(() => {
    const o = {};
    for (const n of WAKTU5) {
      o['adzan' + n] = Math.max(0, adzan.nilai.indexOf(cfg['adzan' + n + 'File']));
      o['tarhim' + n] = Math.max(0, tarhim.nilai.indexOf(cfg['tarhim' + n + 'File']));
    }
    return o;
  });
  const simpan = () => {
    for (const n of WAKTU5) {
      cfg['adzan' + n + 'File'] = adzan.nilai[sel['adzan' + n]] || '';
      cfg['tarhim' + n + 'File'] = tarhim.nilai[sel['tarhim' + n]] || '';
    }
    simpanData(); infoVisual('Seluruh Pilihan Audio Berhasil Disimpan.'); nav.awal();
  };
  const tg = (teks, key) => <Toggle key={key} teks={teks} nilai={c[key]} onPress={() => { cfg[key] = !cfg[key]; simpanData(); }} />;
  return (
    <Layar judul="Adzan & Tarhim" onBack={nav.awal}>
      <Judul teks="1. JADWAL SIARAN ADZAN (KHUSUS TIAP WAKTU)" />
      {WAKTU5.map((n) => (
        <PilihList key={'a' + n} judul={`Memori Adzan ${n}${n === 'Subuh' ? ' (Disunnahkan Tatswib)' : ''}:`} daftar={adzan.nama} indeks={sel['adzan' + n]} onPilih={(i) => setSel((s) => ({ ...s, ['adzan' + n]: i }))} />
      ))}
      <Judul teks="2. SAKELAR ADZAN 5 WAKTU" />
      {WAKTU5.map((n) => tg('Adzan ' + n, 'adzan_' + n.toLowerCase() + '_on'))}
      <Judul teks="3. SAKELAR TARHIM 5 WAKTU" />
      {WAKTU5.map((n) => tg('Tarhim ' + n, 'tarhim_' + n.toLowerCase() + '_on'))}
      <Judul teks="4. JADWAL SIARAN TARHIM (KHUSUS TIAP WAKTU)" />
      {WAKTU5.map((n) => (
        <PilihList key={'t' + n} judul={`Memori Tarhim ${n}:`} daftar={tarhim.nama} indeks={sel['tarhim' + n]} onPilih={(i) => setSel((s) => ({ ...s, ['tarhim' + n]: i }))} />
      ))}
      <Tombol teks="SIMPAN SEMUA PENGATURAN ADZAN & TARHIM" onPress={simpan} />
    </Layar>
  );
}

export function MemoriMurottal({ nav }) {
  const c = useCfg();
  const [ver, setVer] = useState(0);
  const mur = useMemo(() => dapatkanDaftarMurottal(), [ver]);
  const [sel, setSel] = useState(() => {
    const o = {};
    for (const n of WAKTU5) { const m = cfg.memMurottal[n]; o[n] = Math.max(0, mur.nilai.indexOf(m && m.path ? m.path : '')); }
    return o;
  });
  const tambah = async () => {
    try {
      const r = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
      if (r.canceled || !r.assets || !r.assets.length) return;
      await salinBerkasKeMurottal(r.assets[0].uri, r.assets[0].name);
      infoVisual('Berkas ditambahkan: ' + r.assets[0].name); setVer((v) => v + 1);
    } catch (e) { infoVisual('Gagal menambah berkas.'); }
  };
  const simpan = () => {
    for (const n of WAKTU5) {
      const baru = mur.nilai[sel[n]] || '';
      const lama = (cfg.memMurottal[n] && cfg.memMurottal[n].path) || '';
      if (baru !== lama) cfg.memMurottal[n] = { path: baru, pos: 0 };
    }
    simpanData(); infoVisual('Seluruh Pilihan Murottal Berhasil Disimpan.'); nav.awal();
  };
  return (
    <Layar judul="Memori Murottal" onBack={nav.awal}>
      <Tombol teks="TAMBAH BERKAS AUDIO DARI PONSEL" warna={WARNA.toska} onPress={tambah} />
      <Judul teks="1. JADWAL SIARAN MUROTTAL (KHUSUS TIAP WAKTU)" />
      {WAKTU5.map((n) => <PilihList key={n} judul={`Memori Murottal ${n}:`} daftar={mur.nama} indeks={sel[n]} onPilih={(i) => setSel((s) => ({ ...s, [n]: i }))} />)}
      <Judul teks="2. SAKELAR MUROTTAL 5 WAKTU" />
      {WAKTU5.map((n) => { const k = 'murottal_' + n.toLowerCase() + '_on'; return <Toggle key={k} teks={'Murottal ' + n} nilai={c[k]} onPress={() => { cfg[k] = !cfg[k]; simpanData(); }} />; })}
      <Tombol teks="SIMPAN SEMUA PENGATURAN MUROTTAL" onPress={simpan} />
    </Layar>
  );
}
