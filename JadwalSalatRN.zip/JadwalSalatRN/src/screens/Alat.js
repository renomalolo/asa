// Alat bantu: kiblat, kalender Hijriyah/Jawa, jadwal harian, alarm pribadi, tes audio
import React, { useEffect, useRef, useState } from 'react';
import { View } from 'react-native';
import { Magnetometer } from 'expo-sensors';
import * as Clipboard from 'expo-clipboard';
import { Judul, Layar, Masukan, Teks, Tombol, WARNA } from '../ui';
import { cfg, simpanData, useCfg } from '../store';
import { ambilTanggalHijriyah } from '../api';
import { formatTanggalIndo, hitungMenitAbsolut, hitungPasaranJawa, jadwalHariIni, selisihWaktu, tambahMenit, tanggalOffset, tglIni } from '../waktu';
import { bicaraGoogleTTS, getar, hentikanAudioDanSimpan, infoVisual, putarAudio, putarAudioDenganCallback } from '../audio';

const KIBLAT = 294;

export function Kiblat({ nav }) {
  const [ada, setAda] = useState(null);
  const [az, setAz] = useState(0);
  const terakhir = useRef(0);
  useEffect(() => {
    let sub = null; let hidup = true;
    Magnetometer.isAvailableAsync().then((ok) => {
      if (!hidup) return;
      setAda(ok);
      if (!ok) { bicaraGoogleTTS('Sensor kompas fisik tidak ditemukan di perangkat Anda. Gunakan metode bayangan matahari.', true); return; }
      bicaraGoogleTTS('Radar aktif. Pegang ponsel mendatar dan ikuti petunjuk suara.', true);
      Magnetometer.setUpdateInterval(300);
      sub = Magnetometer.addListener(({ x, y }) => {
        const a = (Math.atan2(-x, y) * 180 / Math.PI + 360) % 360; // ponsel mendatar
        setAz(Math.round(a));
        const now = Date.now() / 1000;
        if (now - terakhir.current < 2) return;
        let diff = a - KIBLAT; if (diff > 180) diff -= 360; else if (diff < -180) diff += 360;
        if (Math.abs(diff) <= 5) { getar(500); bicaraGoogleTTS('Tepat! Anda menghadap Kiblat.', true); terakhir.current = now + 1; }
        else if (Math.abs(diff) <= 30) { bicaraGoogleTTS(diff > 0 ? 'Kiri sedikit.' : 'Kanan sedikit.', true); terakhir.current = now; }
        else if (now - terakhir.current >= 4) { bicaraGoogleTTS(diff > 0 ? 'Putar ke kiri.' : 'Putar ke kanan.', true); terakhir.current = now; }
      });
    });
    return () => { hidup = false; if (sub) sub.remove(); };
  }, []);
  return (
    <Layar judul="Radar Kiblat" onBack={nav.kembali}>
      {ada === false ? (
        <Teks teks={'Sensor kompas fisik tidak ditemukan. Metode Bayangan Matahari:\n\nPada sore hari menjelang Maghrib, berdirilah menghadap ke arah matahari terbenam, lalu serongkan badan sedikit ke kanan (sekitar 294 derajat). Itulah arah Kiblat Anda.'} />
      ) : (
        <Teks besar tengah teks={`Arah ponsel: ${az}°\nKiblat: ${KIBLAT}°`} />
      )}
    </Layar>
  );
}

function Kalender({ nav, judul, ambil, koreksi }) {
  const c = useCfg();
  const [off, setOff] = useState(0);
  const [teks, setTeks] = useState('');
  const muat = async (o) => {
    setOff(o); setTeks('Memuat data...');
    const masehi = formatTanggalIndo(tanggalOffset(o));
    const hasil = await ambil(o);
    const akhir = `${masehi}.\nBertepatan dengan ${hasil}`;
    setTeks(akhir); bicaraGoogleTTS(akhir.replace(/\n/g, ' '), true);
  };
  useEffect(() => { muat(0); }, []);
  const geser = (d) => { cfg.koreksiHijriyah += d; simpanData(); muat(off); };
  return (
    <Layar judul={judul} onBack={nav.kembali}>
      <Teks besar tengah warna={WARNA.hijau} teks={teks} />
      {koreksi ? (
        <>
          <Judul teks={`Koreksi Kalender Saat Ini: ${c.koreksiHijriyah} Hari`} />
          <Tombol teks="[-] MUNDUR 1 HARI" warna={WARNA.oranye} onPress={() => geser(-1)} />
          <Tombol teks="[+] MAJU 1 HARI" warna={WARNA.hijau} onPress={() => geser(1)} />
        </>
      ) : null}
      <Tombol teks="SALIN TEKS KE PAPAN KLIP" onPress={async () => { await Clipboard.setStringAsync(teks); infoVisual('Teks disalin.'); }} />
      <Tombol teks="CEK HARI SELANJUTNYA" warna={WARNA.toska} onPress={() => muat(off + 1)} />
      <Tombol teks="CEK HARI INI" warna="#607D8B" onPress={() => muat(0)} />
      <Tombol teks="CEK HARI SEBELUMNYA" warna={WARNA.toska} onPress={() => muat(off - 1)} />
    </Layar>
  );
}
export const Hijriyah = ({ nav }) => <Kalender nav={nav} judul="Kalender Hijriyah" koreksi ambil={async (o) => { const h = await ambilTanggalHijriyah(o); return h ? h.teks : 'Gagal memuat.'; }} />;
export const Jawa = ({ nav }) => <Kalender nav={nav} judul="Kalender Jawa" ambil={async (o) => `pasaran ${hitungPasaranJawa(o)}`} />;

export function JadwalHarian({ nav }) {
  useCfg();
  const [off, setOff] = useState(0);
  const tgl = tanggalOffset(off);
  const j = cfg.jadwalSebulan && typeof cfg.jadwalSebulan === 'object' ? cfg.jadwalSebulan[tgl] : null;
  const w = (n) => tambahMenit(j[n], selisihWaktu(n));
  return (
    <Layar judul="Jadwal Harian" onBack={nav.kembali}>
      {j ? (
        <>
          <Judul teks={'Jadwal ' + formatTanggalIndo(tgl)} />
          <Teks besar teks={`Subuh: ${w('Subuh')}\nTerbit: ${j.Terbit}\nDhuha: ${j.Dhuha}\nDzuhur: ${w('Dzuhur')}\nAshar: ${w('Ashar')}\nMaghrib: ${w('Maghrib')}\nIsya: ${w('Isya')}`} />
        </>
      ) : <Judul teks="Data tidak tersedia" />}
      <View>
        <Tombol teks="SEBELUMNYA" warna={WARNA.oranye} onPress={() => setOff(off - 1)} />
        <Tombol teks="HARI INI" warna={WARNA.hijau} onPress={() => setOff(0)} />
        <Tombol teks="SELANJUTNYA" onPress={() => setOff(off + 1)} />
      </View>
    </Layar>
  );
}

export function Alarm({ nav }) {
  const [waktu, setWaktu] = useState(cfg.alarm_waktu || '');
  const [pesan, setPesan] = useState(cfg.alarm_pesan || '');
  return (
    <Layar judul="Alarm Pribadi" onBack={nav.kembali}>
      <Masukan judul="Waktu Alarm (Format HH:MM, contoh: 03:15):" nilai={waktu} onUbah={setWaktu} placeholder="03:15" keyboardType="numbers-and-punctuation" />
      <Masukan judul="Pesan Suara (Teks TTS):" nilai={pesan} onUbah={setPesan} />
      <Tombol teks="SIMPAN ALARM" warna={WARNA.hijau} onPress={() => {
        if (waktu !== '' && hitungMenitAbsolut(waktu) === -1) { infoVisual('Format waktu salah. Gunakan HH:MM (contoh: 03:15).'); return; }
        cfg.alarm_waktu = waktu; cfg.alarm_pesan = pesan; simpanData(); infoVisual('Alarm pribadi disimpan.'); nav.kembali();
      }} />
      <Tombol teks="HAPUS ALARM" warna={WARNA.oranye} onPress={() => { cfg.alarm_waktu = ''; cfg.alarm_pesan = ''; simpanData(); infoVisual('Alarm pribadi dinonaktifkan.'); nav.kembali(); }} />
    </Layar>
  );
}

export function TesAudio({ nav }) {
  const t = (teks, fn) => <Tombol key={teks} teks={teks} onPress={fn} />;
  const sis = (k) => () => putarAudioDenganCallback('sistem', k, null);
  return (
    <Layar judul="Dasbor Tes Audio Terpadu" onBack={nav.kembali}>
      <Tombol teks="HENTIKAN SEMUA AUDIO" warna={WARNA.pink} onPress={() => { hentikanAudioDanSimpan(); infoVisual('Audio dihentikan.'); }} />
      <Judul teks="UJI KINERJA SISTEM SUARA:" />
      {t('1. UJI SUARA TTS', () => bicaraGoogleTTS('Sistem asisten suara merespons normal.', true))}
      {t('2. BUMPER / PEMBUKA', () => putarAudio('sistem', 'bumper'))}
      {t('3. TARHIM (OTOMATIS / ACAK)', () => putarAudio('sistem', 'tarhim'))}
      <Judul teks="UJI MUROTTAL:" />
      {t('4. MUROTTAL ACAK (MURNI)', () => putarAudio('murottal', ''))}
      {t('5. MUROTTAL SUBUH', () => putarAudio('murottal', 'subuh'))}
      {t("6. MUROTTAL AL-JUMU'AH", () => putarAudio('murottal', 'aljumuah'))}
      <Judul teks="UJI ALARM WAKTU KHUSUS:" />
      {t('7. PERINGATAN TERBIT (10 MNT)', sis('peringatanterbit'))}
      {t('8. WAKTU TERBIT (SYURUQ)', sis('terbit'))}
      {t('9. ALARM DHUHA', sis('dhuha'))}
      {t('10. ALARM TAHAJUD', sis('tahajud'))}
      {t('11. ALARM SAHUR', sis('sahur'))}
      <Judul teks="UJI ADZAN DAN IQOMAH:" />
      {['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'].map((n, i) => t(`${12 + i}. UJI ADZAN ${n.toUpperCase()}`, () => putarAudio('adzan', n)))}
      {t('17. UJI IQOMAH', () => putarAudio('sistem', 'iqomah'))}
    </Layar>
  );
}
