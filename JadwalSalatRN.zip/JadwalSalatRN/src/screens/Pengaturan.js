// Sakelar ibadah, audio & volume, durasi, pengaturan cerdas, suara TTS, diagnostik, panduan, tentang
import React, { useEffect, useState } from 'react';
import { Judul, Layar, Pilihan, Teks, Tombol, Toggle, WARNA } from '../ui';
import { cfg, simpanData, useCfg } from '../store';
import { bicaraGoogleTTS, daftarSuaraID, DIR_MUROTTAL } from '../audio';
import { bukaPengaturanBaterai } from '../sistem';

const tg = (c, teks, key) => <Toggle key={key} teks={teks} nilai={c[key]} onPress={() => { cfg[key] = !cfg[key]; simpanData(); }} />;

export function Sunnah({ nav }) {
  const c = useCfg();
  return (
    <Layar judul="Sakelar Ibadah Lainnya" onBack={nav.kembali}>
      {tg(c, 'Mode Musafir (Hak Jamak/Qashar)', 's_musafir')}
      {tg(c, 'Mode Khusyuk (Getar)', 's_khusyuk')}
      {tg(c, 'Kehati-hatian (15 mnt akhir)', 's_kehatihatian')}
      {tg(c, 'Peringatan Pra-Terbit (10 Mnt)', 's_preterbit')}
      {tg(c, 'Alarm Waktu Terbit (Syuruq)', 's_terbit')}
      {tg(c, 'Alarm Dhuha', 's_dhuha')}
      {tg(c, 'Alarm Tahajud', 's_tahajud')}
      {tg(c, 'Pengingat Puasa Lengkap', 's_puasa')}
      {tg(c, 'Imsak', 's_imsak')}
      {tg(c, 'Protokol Jumat', 's_jumat')}
      {tg(c, 'Laporan Bisu Tiap Jam', 's_jam')}
      {tg(c, 'Pengingat Sunnah Rawatib setelah adzan', 's_rawatib')}
      {tg(c, 'Istiwa (larangan salat)', 's_istiwa')}
      <Judul teks="SAKELAR IQOMAH:" />
      {tg(c, 'Iqomah', 'iqomah_on')}
    </Layar>
  );
}

export function AudioVolume({ nav }) {
  const c = useCfg();
  const atur = (key, d) => { cfg[key] = Math.max(10, Math.min(100, cfg[key] + d)); simpanData(); };
  return (
    <Layar judul="Audio & Volume Cerdas" onBack={nav.kembali}>
      <Judul teks={`VOLUME ADZAN KELIMA WAKTU (${c.volAdzan}%):`} />
      <Tombol teks="TURUNKAN 10%" warna={WARNA.oranye} onPress={() => atur('volAdzan', -10)} />
      <Tombol teks="NAIKKAN 10%" warna={WARNA.hijau} onPress={() => atur('volAdzan', 10)} />
      <Judul teks={`VOLUME MUROTTAL & SISTEM (${c.volMurottal}%):`} />
      <Tombol teks="TURUNKAN 10%" warna={WARNA.oranye} onPress={() => atur('volMurottal', -10)} />
      <Tombol teks="NAIKKAN 10%" warna={WARNA.hijau} onPress={() => atur('volMurottal', 10)} />
    </Layar>
  );
}

const teksOpsi = (v, nol) => (v === 0 ? nol || 'OFF' : v === -1 ? 'OTOMATIS' : String(v));
export function Durasi({ nav }) {
  const c = useCfg();
  const opsi = (judul, key, arr, nol) => (
    <Pilihan
      key={key} judul={`${judul} (${c[key] === 0 ? nol || 'OFF' : c[key] === -1 ? 'OTOMATIS' : c[key] + ' Menit'})`}
      opsi={arr.map((v) => ({ label: teksOpsi(v, nol), nilai: v }))} nilai={c[key]}
      onPilih={(v) => { cfg[key] = v; simpanData(); }}
    />
  );
  return (
    <Layar judul="Durasi Waktu" onBack={nav.kembali}>
      {tg(c, 'Deteksi durasi file tarhim dan murottal otomatis', 'deteksiOtomatis')}
      <Teks kecil teks="Saat ON, lama tarhim dan murottal dibaca dari panjang file aslinya. Hanya jam mulai yang digeser supaya selesai pas sebelum adzan. Adzan tidak pernah ditunda. Pilihan menit di bawah diabaikan untuk tarhim dan murottal." />
      {opsi('Ya Arhamarrohimin (Pra-Murottal)', 'waktuArham', [0, 5, 10, 15, 20])}
      {opsi('Durasi Murottal Pra-Adzan', 'waktuMurottal', [-1, 0, 10, 15, 30, 45, 60])}
      {opsi('Durasi Tarhim Harian', 'waktuTarhim', [0, 5, 6, 10, 15], 'OTOMATIS')}
      {opsi('Jeda Iqomah', 'waktuIqomah', [5, 10, 15, 20])}
      {opsi('Durasi Mode Khusyuk', 'durasiKhusyuk', [20, 30, 40, 60])}
    </Layar>
  );
}

export function Cerdas({ nav }) {
  const c = useCfg();
  return (
    <Layar judul="Pengaturan Cerdas" onBack={nav.kembali}>
      {tg(c, 'By-pass Volume HP', 'autoVolume')}
      {tg(c, 'Getar Awal Sholat', 'getarAwal')}
      {tg(c, 'Teks TTS bervariasi', 'ttsVarian')}
      {tg(c, 'Penjaga sunyi (audio hening agar HP tak tidur)', 'penjagaSunyi')}
    </Layar>
  );
}

export function SuaraTTS({ nav }) {
  const c = useCfg();
  const [suara, setSuara] = useState([]);
  useEffect(() => { daftarSuaraID().then(setSuara); }, []);
  const item = [
    ...suara.map((v, i) => ({ label: `Suara ${i + 1} (${/network/i.test(v.identifier || v.name || '') ? 'Jaringan' : 'Lokal'})`, nilai: v.identifier })),
    { label: 'Default Sistem', nilai: 'default' },
  ];
  return (
    <Layar judul="Suara TTS" onBack={nav.kembali}>
      {item.map((it) => (
        <Tombol key={it.nilai} teks={(it.nilai === c.jenisSuaraTTS ? '[ TERPILIH ] ' : '') + it.label} onPress={() => {
          cfg.jenisSuaraTTS = it.nilai; simpanData(); bicaraGoogleTTS('Uji coba suara.', true);
        }} />
      ))}
    </Layar>
  );
}

export function Diagnostik({ nav }) {
  const c = useCfg();
  let n = 0; try { n = DIR_MUROTTAL.list().length; } catch (e) {}
  return (
    <Layar judul="Diagnostik" onBack={nav.kembali}>
      <Teks besar teks={`1. API: ${c.idKota ? 'TERHUBUNG' : 'GAGAL'}\n2. Lokasi: ${c.lokasiDitemukan || 'KOSONG'}\n3. Audio ditemukan: ${n} file\n4. Path: ${DIR_MUROTTAL.uri}\n5. Murottal: ${c.modeMurottal.toUpperCase()}\n6. TTS: ${c.jenisSuaraTTS}`} />
      <Tombol teks="CEK IZIN BATERAI" warna={WARNA.pink} onPress={bukaPengaturanBaterai} />
    </Layar>
  );
}

export const Panduan = ({ nav }) => (
  <Layar judul="Panduan" onBack={nav.kembali}>
    <Teks teks={`PANDUAN PENGGUNAAN JADWAL SALAT BY RENO\n\n1. Pengaturan Lokasi: Buka Pengaturan Lokasi, pilih provinsi dan kota.\n2. Sakelar Master: Di beranda, matikan tombol ini jika Anda ingin menghentikan seluruh sistem siaran secara instan.\n3. Adzan & Tarhim: Anda bisa mematikan adzan waktu tertentu melalui menu Adzan & Tarhim.\n4. Mode Khusyuk: Mengecilkan nada dering saat sholat berlangsung.\n5. Selisih Waktu Manual: Di beranda, geser waktu Subuh, Dzuhur, Ashar, Maghrib, dan Isya maju atau mundur beberapa menit.`} />
  </Layar>
);

export const Tentang = ({ nav }) => (
  <Layar judul="Tentang Aplikasi" onBack={nav.kembali}>
    <Teks teks={`JADWAL SALAT BY RENO\n\nSistem asisten cerdas purna waktu untuk pengelolaan siaran masjid dan pengingat ibadah.\n\nPENGEMBANG & SOURCE CODE:\nDikembangkan oleh Hamba Allah Codsos.\n\nKREDIT & PENGHARGAAN TIM:\n1. Mas Yeni Setiawan (Penguji VIP & Penasihat Utama atas saran dan idenya yang luar biasa)\n2. Pak Ragil (Penasihat Senior)\n3. Kang Supri (Tim Penguji)\n4. Kang Datsun (Tim Evaluasi Aksesibilitas)\n\nLISENSI MUTLAK (DIGITAL WAQAF):\nSource Code diwakafkan 100% GRATIS untuk umat. Dilarang memperjualbelikan atau memonetisasi sistem ini.\n\nKATA PENUTUP:\nSistem ini adalah wujud syiar dakwah yang menembus batas keterbatasan visual. Semoga setiap kumandang adzan dari mesin ini menjadi saksi amal jariyah kita kelak. Hasbunallah wa ni'mal wakil.\n\n(Versi React Native — port dari versi AndLua+.)`} />
  </Layar>
);
