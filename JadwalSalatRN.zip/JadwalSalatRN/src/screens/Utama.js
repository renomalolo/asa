// Menu utama (tampilkanMenuUtama)
import React, { useEffect, useState } from 'react';
import { BackHandler } from 'react-native';
import { Layar, Teks, Tombol, Toggle, WARNA } from '../ui';
import { cfg, resetPabrik, setGembok, simpanData, useCfg } from '../store';
import { S } from '../state';
import { formatTanggalIndo, hitungSisaWaktuTeks, tglIni } from '../waktu';
import { bicaraGoogleTTS, hentikanAudioDanSimpan } from '../audio';
import { hentikanMesin, mulaiMesin } from '../engine';
import { deteksiLokasiOtomatis } from '../lokasi';
import { bukaPengaturanBaterai } from '../sistem';

export default function Utama({ nav }) {
  const c = useCfg();
  const [, tik] = useState(0);
  useEffect(() => { const t = setInterval(() => tik((n) => n + 1), 30000); return () => clearInterval(t); }, []);

  const master = () => {
    cfg.master_aktif = !cfg.master_aktif; simpanData(); mulaiMesin(500);
    if (!cfg.master_aktif) hentikanAudioDanSimpan();
    bicaraGoogleTTS(cfg.master_aktif ? 'Sistem siaran master diaktifkan.' : 'Sistem siaran dimatikan secara total.', true);
  };
  const restart = () => {
    setGembok({}); hentikanAudioDanSimpan(); mulaiMesin(1000);
    bicaraGoogleTTS('Sistem dimulai ulang.', true);
  };
  const reset = async () => {
    hentikanAudioDanSimpan(); await resetPabrik(); S.bulanHijriyahIni = ''; mulaiMesin(1000);
    bicaraGoogleTTS('Sistem direset ke kondisi awal.', true);
  };

  return (
    <Layar judul="Jadwal Salat by Reno">
      <Tombol teks="BUKA PENGATURAN BATERAI (agar jadwal tetap jalan)" warna={WARNA.pink} onPress={bukaPengaturanBaterai} />
      <Teks besar teks={`LOKASI: ${c.lokasiDitemukan || c.kota}\n${formatTanggalIndo(tglIni())}\n\n${hitungSisaWaktuTeks()}`} />
      <Toggle teks={c.master_aktif ? 'MASTER SIARAN AKTIF' : 'MASTER SIARAN MATI'} nilai={c.master_aktif} onPress={master} />
      <Tombol teks="PENGATURAN ADZAN & TARHIM" warna={WARNA.oranye} onPress={() => nav.ke('AdzanTarhim')} />
      <Tombol teks="MEMORI MUROTTAL (SUBUH - ISYA)" warna={WARNA.coklat} onPress={() => nav.ke('MemoriMurottal')} />
      <Tombol teks="PENGATURAN LOKASI" warna={WARNA.toska} onPress={() => nav.ke('Lokasi')} />
      <Toggle
        teks={c.lokasiOtomatis ? 'LOKASI OTOMATIS (IKUT POSISI HP)' : 'LOKASI OTOMATIS'} nilai={c.lokasiOtomatis}
        onPress={() => {
          cfg.lokasiOtomatis = !cfg.lokasiOtomatis; simpanData();
          if (cfg.lokasiOtomatis) deteksiLokasiOtomatis(false, () => tik((n) => n + 1));
          else bicaraGoogleTTS('Lokasi otomatis dimatikan.', true);
        }}
      />
      <Tombol teks="SELISIH WAKTU MANUAL" warna={WARNA.ungu} onPress={() => nav.ke('Selisih')} />
      <Tombol teks="MENU FITUR LANJUTAN & INFO" warna={WARNA.biru} onPress={() => nav.ke('Fitur')} />
      <Tombol teks="RESTART SISTEM" warna={WARNA.oranye} onPress={restart} />
      <Tombol teks="RESET PABRIK (HAPUS DATA)" warna={WARNA.merah} onPress={reset} />
      <Tombol teks="KELUAR TOTAL (MESIN BERHENTI)" warna={WARNA.abuTua} onPress={() => { hentikanAudioDanSimpan(); hentikanMesin(); BackHandler.exitApp(); }} />
      <Teks kecil warna="#888" teks={'Sistem berjalan di latar belakang.\nTekan tombol Kembali di ponsel untuk menyembunyikan aplikasi.'} />
    </Layar>
  );
}
