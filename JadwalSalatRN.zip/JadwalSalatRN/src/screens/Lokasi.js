// Pengaturan lokasi manual + profil lokasi tersimpan
import React, { useState } from 'react';
import { Layar, PilihList, Tombol, WARNA } from '../ui';
import { cfg, simpanData, useCfg } from '../store';
import { DAFTAR_KOTA, DAFTAR_PROVINSI } from '../data';
import { sinkronisasiJadwal } from '../api';
import { bicaraGoogleTTS, infoVisual } from '../audio';

export function Lokasi({ nav }) {
  const [p, setP] = useState(0);
  const [k, setK] = useState(0);
  const kota = DAFTAR_KOTA[DAFTAR_PROVINSI[p]];
  const simpan = async () => {
    const nama = kota[k]; if (!nama) return;
    cfg.kota = nama; cfg.lokasiOtomatis = false; simpanData();
    bicaraGoogleTTS('Mencari jadwal untuk ' + nama, true);
    const r = await sinkronisasiJadwal(nama);
    infoVisual(r.ok ? 'Jadwal tersimpan.' : 'Gagal menarik jadwal.');
    nav.awal();
  };
  return (
    <Layar judul="Pilih Wilayah" onBack={nav.awal}>
      <PilihList judul="Pilih provinsi atau wilayah:" daftar={DAFTAR_PROVINSI} indeks={p} onPilih={(i) => { setP(i); setK(0); }} />
      <PilihList judul="Pilih kota atau kabupaten:" daftar={kota} indeks={k} onPilih={setK} />
      <Tombol teks="SIMPAN DAN CARI JADWAL" warna={WARNA.hijau} onPress={simpan} />
    </Layar>
  );
}

export function ProfilLokasi({ nav }) {
  const c = useCfg();
  const bisaSimpan = c.kota !== 'Belum Diatur' && c.idKota !== '';
  return (
    <Layar judul="Profil Lokasi" onBack={nav.kembali}>
      {bisaSimpan ? (
        <Tombol teks="SIMPAN PROFIL" warna={WARNA.hijau} onPress={() => {
          if (cfg.profilLokasi[cfg.kota]) return;
          cfg.profilLokasi[cfg.kota] = { kota: cfg.kota, idKota: cfg.idKota, lokasi: cfg.lokasiDitemukan };
          simpanData(); infoVisual('Profil disimpan.');
        }} />
      ) : null}
      {Object.entries(c.profilLokasi).map(([nama, d]) => (
        <React.Fragment key={nama}>
          <Tombol teks={`${nama} (${d.lokasi})`} onPress={() => {
            cfg.kota = d.kota; cfg.lokasiOtomatis = false; cfg.idKota = d.idKota; cfg.lokasiDitemukan = d.lokasi; simpanData();
            sinkronisasiJadwal(d.kota); nav.awal();
          }} />
          <Tombol teks={`  [HAPUS ${nama}]`} warna="#F44336" onPress={() => { delete cfg.profilLokasi[nama]; simpanData(); }} />
        </React.Fragment>
      ))}
    </Layar>
  );
}
