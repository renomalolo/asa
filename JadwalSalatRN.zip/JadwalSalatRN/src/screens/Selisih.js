// Selisih waktu manual per waktu salat (-60 .. +60 menit)
import React from 'react';
import { Judul, Layar, Teks, Tombol, WARNA } from '../ui';
import { cfg, simpanData, useCfg, WAKTU5 } from '../store';
import { jadwalHariIni, selisihWaktu, tambahMenit, teksSelisih } from '../waktu';
import { bicaraGoogleTTS } from '../audio';
import { View } from 'react-native';

export default function Selisih({ nav }) {
  const c = useCfg();
  const jdw = jadwalHariIni();
  const ubah = (n, delta) => {
    const baru = delta === 0 ? 0 : Math.max(-60, Math.min(60, (cfg.selisih[n] || 0) + delta));
    cfg.selisih[n] = baru; simpanData();
    let ucap = `${n} ${teksSelisih(baru)}`;
    if (jdw && jdw[n]) ucap += `, jadi ${tambahMenit(jdw[n], selisihWaktu(n))}`;
    bicaraGoogleTTS(ucap, true);
  };
  return (
    <Layar judul="Selisih Waktu Manual" onBack={nav.awal}>
      <Teks teks="Geser waktu salat maju atau mundur (dalam menit) dari jadwal asli. Adzan, tarhim, murottal, dan iqomah ikut menyesuaikan. Batas -60 sampai +60 menit." />
      {WAKTU5.map((n) => {
        const sel = c.selisih[n] || 0;
        let teks = `${n}: ${teksSelisih(sel)}`;
        if (jdw && jdw[n]) teks += `\nAsli ${jdw[n]}, dipakai ${tambahMenit(jdw[n], selisihWaktu(n))}`;
        return (
          <View key={n}>
            <Judul teks={teks} />
            <View style={{ flexDirection: 'row' }}>
              {[['Mundur 5', -5, WARNA.oranye], ['Mundur 1', -1, WARNA.oranye], ['Nol', 0, WARNA.abu], ['Maju 1', 1, WARNA.hijau], ['Maju 5', 5, WARNA.hijau]].map(([t, d, w]) => (
                <Tombol key={t} teks={t} warna={w} kecil onPress={() => ubah(n, d)} style={{ flex: 1, marginHorizontal: 2 }} />
              ))}
            </View>
          </View>
        );
      })}
      <Tombol teks="NOLKAN SEMUA SELISIH" warna={WARNA.merah} onPress={() => {
        for (const n of WAKTU5) cfg.selisih[n] = 0;
        simpanData(); bicaraGoogleTTS('Semua selisih waktu dinolkan.', true);
      }} />
    </Layar>
  );
}
