// State runtime (tidak disimpan ke disk). Pengganti variabel global _G.* pada versi Lua.
import { useEffect, useState } from 'react';

export const S = {
  sesiMesin: 1,
  detakJantung: Date.now(),
  tanggalSistem: '',
  bulanHijriyahIni: '',
  mesinPanas: false,
  detikKeJendela: 0,

  tarhimBerjalan: false,
  tarhimMulai: 0,
  cacheTarhim: {},
  cacheDurasi: {},
  cachePilih: {},
  cacheMurottal: {},

  murottalMem: null,     // {waktu, path, t}
  murottalRantai: null,  // {waktu, t}
  slackLewat: false,
  volTerakhirDiputar: 100,
  sedangPutarSpesial: false,
  volumeLama: null,
  ringerLama: null,
  sedangDeteksiLokasi: false,
  watchdogAktif: false,
  lokasiLoopAktif: false,
};

// ---- Status pemutar (pengganti dialog "HENTIKAN SIARAN") ----
let player = { aktif: false, judul: '' };
const pend = new Set();
export function setPlayerUI(p) { player = p; pend.forEach((f) => f()); }
export function usePlayerUI() {
  const [, setN] = useState(0);
  useEffect(() => {
    const f = () => setN((n) => n + 1);
    pend.add(f);
    return () => pend.delete(f);
  }, []);
  return player;
}

// ---- Pesan singkat (pengganti Toast) ----
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export function tunda(ms, fn) {
  return setTimeout(() => { try { const r = fn(); if (r && r.catch) r.catch(() => {}); } catch (e) {} }, Math.floor(ms));
}
