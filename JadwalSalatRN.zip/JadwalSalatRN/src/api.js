// Panggilan jaringan: jadwal salat (api.myquran.com) dan tanggal Hijriyah (api.aladhan.com)
import { cfg, simpanData } from './store';
import { NAMA_HARI, isLewatMaghrib, nowSec } from './waktu';

export async function getAPI(url, timeoutMs = 20000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const r = await fetch(url, { signal: ac.signal });
    if (r.status === 200) return { ok: true, isi: await r.text() };
  } catch (e) { /* jatuh ke kegagalan di bawah */ } finally { clearTimeout(t); }
  return { ok: false, isi: 'Peladen menolak akses.' };
}

const pad2 = (n) => String(n).padStart(2, '0');

// Cari ID kota -> unduh jadwal sebulan -> simpan di cfg.jadwalSebulan.
// Mengembalikan { ok, hasil } ; hasil = nama lokasi resmi, atau pesan galat.
export async function sinkronisasiJadwal(namaKota) {
  try {
    const kBersih = String(namaKota || '').toLowerCase()
      .replace(/^kota\s+/, '').replace(/^kab\.?\s+/, '').replace(/^kabupaten\s+/, '');
    const r1 = await getAPI('https://api.myquran.com/v2/sholat/kota/cari/' + encodeURIComponent(kBersih));
    if (!r1.ok) return { ok: false, hasil: 'Gagal menghubungi peladen.' };
    let d;
    try { d = JSON.parse(r1.isi); } catch (e) { return { ok: false, hasil: 'Kota tidak ditemukan.' }; }
    if (!d || d.status !== true) return { ok: false, hasil: 'Kota tidak ditemukan.' };
    if (!Array.isArray(d.data) || d.data.length === 0) return { ok: false, hasil: 'Data kosong.' };
    const id = String(d.data[0].id || '');
    const nResmi = String(d.data[0].lokasi || '');
    if (!id) return { ok: false, hasil: 'ID tidak ditemukan.' };
    cfg.idKota = id; cfg.lokasiDitemukan = nResmi; simpanData();

    const skr = new Date();
    const r2 = await getAPI(`https://api.myquran.com/v2/sholat/jadwal/${id}/${skr.getFullYear()}/${pad2(skr.getMonth() + 1)}`);
    if (!r2.ok) return { ok: false, hasil: 'Gagal unduh jadwal.' };
    let d2;
    try { d2 = JSON.parse(r2.isi); } catch (e) { return { ok: false, hasil: 'Format jadwal salah.' }; }
    if (!d2 || d2.status !== true) return { ok: false, hasil: 'Format jadwal salah.' };
    const arr = d2.data && d2.data.jadwal;
    if (!Array.isArray(arr)) return { ok: false, hasil: 'Tabel kosong.' };
    const baru = {};
    for (const it of arr) {
      const tgl = String(it.date || '');
      if (!tgl) continue;
      baru[tgl] = {
        Subuh: it.subuh || '', Terbit: it.terbit || '', Dhuha: it.dhuha || '', Dzuhur: it.dzuhur || '',
        Ashar: it.ashar || '', Maghrib: it.maghrib || '', Isya: it.isya || '',
      };
    }
    cfg.jadwalSebulan = baru;
    simpanData();
    return { ok: true, hasil: nResmi };
  } catch (e) {
    return { ok: false, hasil: 'Galat: ' + String(e && e.message) };
  }
}

const BULAN_HIJRI = {
  'Muharram': 'Muharram', 'Safar': 'Safar', "Rabi' al-awwal": 'Rabiul Awal', "Rabi' al-thani": 'Rabiul Akhir',
  'Jumada al-awwal': 'Jumadil Awal', 'Jumada al-thani': 'Jumadil Akhir', 'Rajab': 'Rajab', "Sha'ban": 'Syakban',
  'Ramadan': 'Ramadhan', 'Shawwal': 'Syawal', "Dhu al-Qi'dah": 'Zulkaidah', 'Dhu al-Hijjah': 'Zulhijah',
};

// Mengembalikan { teks, tgl, bln } atau null bila gagal.
export async function ambilTanggalHijriyah(offsetHari) {
  try {
    const geser = offsetHari === 0 && isLewatMaghrib();
    let tReal = nowSec() + offsetHari * 86400;
    if (geser) tReal += 86400;
    const namaHari = NAMA_HARI[new Date(tReal * 1000).getDay()];
    const tHijri = new Date((tReal + (cfg.koreksiHijriyah || 0) * 86400) * 1000);
    const tgl = `${pad2(tHijri.getDate())}-${pad2(tHijri.getMonth() + 1)}-${tHijri.getFullYear()}`;
    const r = await getAPI('https://api.aladhan.com/v1/gToH/' + tgl);
    if (!r.ok) return null;
    const d = JSON.parse(r.isi);
    if (!d || !d.data) return null;
    const h = d.data.hijri;
    const bln = BULAN_HIJRI[h.month.en] || h.month.en;
    return {
      teks: `${geser ? 'Malam ' : ''}${namaHari}, ${h.day} ${bln} ${h.year} Hijriyah`,
      tgl: parseInt(h.day, 10),
      bln,
    };
  } catch (e) { return null; }
}

