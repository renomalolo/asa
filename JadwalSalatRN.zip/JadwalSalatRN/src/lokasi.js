// Lokasi otomatis: izin lokasi -> titik koordinat -> nama kota/kabupaten -> jadwal salat setempat.
import * as Location from 'expo-location';
import { cfg, simpanData } from './store';
import { S, tunda } from './state';
import { getAPI, sinkronisasiJadwal } from './api';
import { nowSec } from './waktu';
import { bicaraGoogleTTS } from './audio';

export async function punyaIzinLokasi() {
  try { return (await Location.getForegroundPermissionsAsync()).granted; } catch (e) { return false; }
}

async function mintaIzinLokasi() {
  if (await punyaIzinLokasi()) return true;
  try { return (await Location.requestForegroundPermissionsAsync()).granted; } catch (e) { return false; }
}

// Mengembalikan { lat, lon } atau null
async function ambilTitikLokasi() {
  try {
    const terakhir = await Location.getLastKnownPositionAsync({ maxAge: 6 * 3600 * 1000 });
    if (terakhir) return { lat: terakhir.coords.latitude, lon: terakhir.coords.longitude };
  } catch (e) {}
  try {
    const p = await Promise.race([
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
      new Promise((r) => setTimeout(() => r(null), 25000)),
    ]);
    if (p) return { lat: p.coords.latitude, lon: p.coords.longitude };
  } catch (e) {}
  return null;
}

export function bersihNamaWilayah(n) {
  n = String(n || '').trim();
  const rendah = n.toLowerCase();
  for (const a of ['kota administrasi ', 'kabupaten administrasi ', 'kabupaten ', 'kota ', 'kab. ', 'kab ']) {
    if (rendah.startsWith(a)) return n.slice(a.length);
  }
  for (const a of [' regency', ' administrative city', ' city']) {
    if (rendah.length > a.length && rendah.endsWith(a)) return n.slice(0, n.length - a.length);
  }
  return n;
}

function buatKandidat() {
  const kand = []; const sudah = new Set();
  const tambah = (n) => {
    n = bersihNamaWilayah(n);
    if (!n) return;
    const k = n.toLowerCase();
    if (sudah.has(k)) return;
    sudah.add(k); kand.push(n);
    if (k.includes('jakarta') && !sudah.has('jakarta')) { sudah.add('jakarta'); kand.push('Jakarta'); }
  };
  return { kand, tambah };
}

// tahap 1: lewat internet
async function namaWilayahOnline(lat, lon) {
  const { kand, tambah } = buatKandidat();
  const url = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat.toFixed(5)}&longitude=${lon.toFixed(5)}&localityLanguage=id`;
  const r = await getAPI(url);
  if (r.ok) {
    try {
      const d = JSON.parse(r.isi);
      const lv5 = []; const lv6 = [];
      const arr = d.localityInfo && d.localityInfo.administrative;
      if (Array.isArray(arr)) for (const o of arr) { if (o.adminLevel === 5) lv5.push(o.name); else if (o.adminLevel === 6) lv6.push(o.name); }
      lv5.forEach(tambah); tambah(d.city); lv6.forEach(tambah); tambah(d.locality);
    } catch (e) {}
  }
  return kand;
}

// tahap 2 (cadangan): geocoder bawaan HP
async function namaWilayahGeocoder(lat, lon) {
  const { kand, tambah } = buatKandidat();
  try {
    const hasil = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lon });
    if (hasil && hasil.length) { const a = hasil[0]; tambah(a.subregion); tambah(a.city); tambah(a.district); }
  } catch (e) {}
  return kand;
}

const JEDA_CEK_LOKASI = 30 * 24 * 3600; // cek ulang tiap 30 hari
export function lokasiPerluDicek() {
  return cfg.kota === 'Belum Diatur' || nowSec() - (Number(cfg.lokasiCekTerakhir) || 0) >= JEDA_CEK_LOKASI;
}

// senyap = true: diam-diam, hanya bicara bila wilayah berubah. onUbah dipanggil bila wilayah berganti.
export async function deteksiLokasiOtomatis(senyap, onUbah) {
  if (S.sedangDeteksiLokasi) return;
  if (senyap && !(await punyaIzinLokasi())) return;
  S.sedangDeteksiLokasi = true;
  const gagal = (pesan) => { S.sedangDeteksiLokasi = false; if (!senyap) bicaraGoogleTTS(pesan, false); };
  const lokasiLama = cfg.lokasiDitemukan;
  try {
    if (!(await mintaIzinLokasi())) { gagal('Izin lokasi ditolak. Silakan pilih kota secara manual di menu Pengaturan Lokasi.'); return; }
    if (!senyap) bicaraGoogleTTS('Mendeteksi lokasi.', true);
    const titik = await ambilTitikLokasi();
    if (!titik) { gagal('Lokasi belum terdeteksi. Nyalakan lokasi di HP, atau pilih kota secara manual.'); return; }

    for (const tahap of [1, 2]) {
      const daftar = tahap === 1 ? await namaWilayahOnline(titik.lat, titik.lon) : await namaWilayahGeocoder(titik.lat, titik.lon);
      for (const nama of daftar) {
        const r = await sinkronisasiJadwal(nama);
        if (r.ok) {
          cfg.kota = nama; cfg.lokasiOtomatis = true; cfg.lokasiCekTerakhir = nowSec(); simpanData();
          S.sedangDeteksiLokasi = false;
          if (!senyap || r.hasil !== lokasiLama) {
            bicaraGoogleTTS(`Lokasi terdeteksi, ${r.hasil}. Jadwal salat sudah disesuaikan.`, true);
            if (onUbah) onUbah();
          }
          return;
        }
      }
    }
    gagal('Nama wilayah belum cocok dengan data jadwal. Silakan pilih kota secara manual.');
  } catch (e) { gagal('Deteksi lokasi gagal.'); }
}

// cek ulang tiap jam (diam-diam)
export function mulaiLoopLokasi(onUbah) {
  if (S.lokasiLoopAktif) return;
  S.lokasiLoopAktif = true;
  const putar = () => tunda(3600000, () => {
    if (cfg.lokasiOtomatis && lokasiPerluDicek()) deteksiLokasiOtomatis(true, onUbah);
    putar();
  });
  putar();
}
