// Helper waktu & tanggal (port dari fungsi-fungsi Lua: tambahMenit, hitungMenitAbsolut, dst.)
import { cfg } from './store';

const pad2 = (n) => String(n).padStart(2, '0');
export const NAMA_HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
export const NAMA_BULAN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

export const nowSec = () => Math.floor(Date.now() / 1000);
export const isoTanggal = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
export const tglIni = () => isoTanggal();
export const jamMenitSekarang = () => { const d = new Date(); return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };
export const detikHariIni = () => { const d = new Date(); return d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds(); };
export const hariKe = () => new Date().getDay(); // 0 = Minggu ... 5 = Jumat
export const tanggalOffset = (offsetHari) => isoTanggal(new Date(Date.now() + offsetHari * 86400000));

const POLA = /(\d\d):(\d\d)/;

export function hitungMenitAbsolut(w) {
  if (typeof w !== 'string') return -1;
  const m = w.match(POLA);
  if (!m) return -1;
  return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
}

export function tambahMenit(w, menit) {
  try {
    if (typeof w !== 'string' || w === '') return '';
    const m = w.match(POLA);
    if (!m) return '';
    let t = parseInt(m[1], 10) * 60 + parseInt(m[2], 10) + (Number(menit) || 0);
    t = ((t % 1440) + 1440) % 1440;
    return `${pad2(Math.floor(t / 60))}:${pad2(Math.floor(t % 60))}`;
  } catch (e) { return w; }
}

// Selisih total (menit): selisih umum (ikhtiar) + selisih manual per waktu
export function selisihWaktu(nama) {
  return (Number(cfg.ikhtiar) || 0) + (Number(cfg.selisih && cfg.selisih[nama]) || 0);
}

export function formatTanggalIndo(tgl) {
  try {
    const m = String(tgl || '').match(/^(\d{4})-(\d\d)-(\d\d)$/);
    if (!m) return tgl || '';
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    return `${NAMA_HARI[d.getDay()]}, ${+m[3]} ${NAMA_BULAN[+m[2] - 1]} ${m[1]}`;
  } catch (e) { return tgl; }
}

export function jadwalHariIni() {
  return cfg.jadwalSebulan && typeof cfg.jadwalSebulan === 'object' ? cfg.jadwalSebulan[tglIni()] || null : null;
}

// true bila sekarang berada 0..6 menit setelah target (jendela toleransi mesin 5 detik)
export function isWaktunya(target) {
  const tm = hitungMenitAbsolut(target);
  if (tm === -1) return false;
  const skr = hitungMenitAbsolut(jamMenitSekarang());
  return ((skr - tm + 1440) % 1440) <= 6;
}

export function isLewatMaghrib() {
  try {
    const jdw = jadwalHariIni();
    const d = new Date();
    if (!jdw || !jdw.Maghrib) return d.getHours() > 17 || (d.getHours() === 17 && d.getMinutes() >= 30);
    const tm = hitungMenitAbsolut(tambahMenit(jdw.Maghrib, selisihWaktu('Maghrib')));
    return d.getHours() * 60 + d.getMinutes() >= tm;
  } catch (e) { return false; }
}

export function hitungSisaWaktuTeks() {
  if (!cfg.jadwalSebulan || typeof cfg.jadwalSebulan !== 'object') return 'Jadwal Belum Diunduh.';
  const jdw = jadwalHariIni();
  if (!jdw || !jdw.Subuh) return 'Jadwal Kosong.';
  const d = new Date();
  const skr = d.getHours() * 60 + d.getMinutes();
  const daftar = [
    { n: 'Subuh', w: tambahMenit(jdw.Subuh, selisihWaktu('Subuh')) },
    { n: 'Terbit', w: jdw.Terbit },
    { n: 'Dzuhur', w: tambahMenit(jdw.Dzuhur, selisihWaktu('Dzuhur')) },
    { n: 'Ashar', w: tambahMenit(jdw.Ashar, selisihWaktu('Ashar')) },
    { n: 'Maghrib', w: tambahMenit(jdw.Maghrib, selisihWaktu('Maghrib')) },
    { n: 'Isya', w: tambahMenit(jdw.Isya, selisihWaktu('Isya')) },
  ];
  let nama = null; let selisih = null;
  for (const w of daftar) {
    const t = hitungMenitAbsolut(w.w);
    if (t !== -1 && t > skr) { nama = w.n; selisih = t - skr; break; }
  }
  if (!nama) {
    nama = 'Subuh Besok';
    selisih = hitungMenitAbsolut(daftar[0].w) + 1440 - skr;
  }
  return `${formatTanggalIndo(tglIni())}. Menuju ${nama}: ${Math.floor(selisih / 60)} Jam ${selisih % 60} Menit.`;
}

export function hitungPasaranJawa(offsetHari) {
  const geser = offsetHari === 0 && isLewatMaghrib();
  let t = nowSec() + offsetHari * 86400;
  if (geser) t += 86400;
  const sHari = Math.floor((t + 25200) / 86400);
  const pasaran = ['Wage', 'Kliwon', 'Legi', 'Pahing', 'Pon'];
  const namaHari = NAMA_HARI[new Date(t * 1000).getDay()];
  return `${geser ? 'Malam ' : ''}${namaHari} ${pasaran[((sHari % 5) + 5) % 5]}`;
}

export function formatMenitDetik(ms) {
  const t = Math.floor((ms || 0) / 1000);
  return `${Math.floor(t / 60)}:${pad2(t % 60)}`;
}

export const teksSelisih = (v) => (v > 0 ? `maju ${v} menit` : v < 0 ? `mundur ${-v} menit` : 'tanpa selisih');
