// Mesin waktu: memeriksa jadwal dan menjalankan adzan, tarhim, murottal, iqomah, dan pengingat.
// Port dari mesinWaktuMasjid() + hitungTundaMesin() pada main.lua.
import * as Notifications from 'expo-notifications';
import { cfg, gembok, setGembok, simpanGembok, WAKTU5 } from './store';
import { S, tunda } from './state';
import {
  detikHariIni, hariKe, hitungMenitAbsolut, hitungSisaWaktuTeks, isWaktunya, jamMenitSekarang,
  nowSec, selisihWaktu, tambahMenit, tglIni,
} from './waktu';
import { ambilTanggalHijriyah, sinkronisasiJadwal } from './api';
import { matikanLayanan, perbaruiNotifLayanan } from './layanan';
import {
  bicaraGoogleTTS, dapatkanTeksVarian, durasiFileMs, eksekusiAutoVolume, eksekusiModeKhusyuk, getar,
  hentikanAudioDanSimpan, infoVisual, jagaMesinTetapHidup, jalankanTarhim, kembalikanVolume,
  matikanPenjagaSunyi, murottalOto, pilihBerkas, putarAudio, putarAudioDenganCallback,
  putarAudioFileLangsung, saatnyaTarhim, sedangMain, siapkanMurottal, siapkanTarhim, sisaMurottalMs,
  susunTeksAwal, tarhimOto,
} from './audio';

const mod = (a, b) => ((a % b) + b) % b;
const MAKS = 240000;

// ============ PENGHEMAT: cek rapat hanya saat mendekati waktu kejadian ============
// Mengembalikan 0 bila mesin harus mengecek sekarang, atau milidetik untuk "tidur".
export async function hitungTundaMesin() {
  try {
    if (!cfg.master_aktif) return MAKS;
    const skr = detikHariIni(); const tgl = tglIni();
    let panas = false; let terdekat = 86400; let berkala = 86400;

    const catat = (mulai, durasi) => {
      const lalu = mod(skr - mulai, 86400);
      if (lalu < durasi) { panas = true; return; }
      const ke = mod(mulai - skr, 86400);
      if (ke < terdekat) terdekat = ke;
    };
    const titik = (wStr, offset = 0) => {
      const m = hitungMenitAbsolut(tambahMenit(wStr, offset));
      if (m !== -1) catat(m * 60 - 20, 300);
    };

    // iqomah yang sedang menunggu
    for (const [k, v] of Object.entries(gembok)) {
      if (k.startsWith('IQOMAH_') && typeof v === 'string') {
        const mi = hitungMenitAbsolut(v);
        if (mi !== -1) catat(mi * 60 - 20, 150); else panas = true;
      }
    }
    if (panas) return 0;

    if (cfg.s_jam) {
      const r = skr % 1800;
      if (r < 110 || r >= 1780) return 0;
      berkala = 1780 - r;
    }
    if (cfg.alarm_waktu) titik(cfg.alarm_waktu, 0);

    const jdw = cfg.jadwalSebulan && typeof cfg.jadwalSebulan === 'object' ? cfg.jadwalSebulan[tgl] : null;
    if (!jdw || !jdw.Subuh) {
      // jadwal hari ini belum ada: coba sinkron otomatis, cek tiap menit
      S.detikKeJendela = Math.min(terdekat, berkala);
      return Math.min(Math.min(terdekat, berkala) * 1000, 60000);
    }

    const wA = {
      Subuh: tambahMenit(jdw.Subuh, selisihWaktu('Subuh')), Terbit: jdw.Terbit,
      Dzuhur: tambahMenit(jdw.Dzuhur, selisihWaktu('Dzuhur')), Ashar: tambahMenit(jdw.Ashar, selisihWaktu('Ashar')),
      Maghrib: tambahMenit(jdw.Maghrib, selisihWaktu('Maghrib')), Isya: tambahMenit(jdw.Isya, selisihWaktu('Isya')),
    };
    const isJumat = hariKe() === 5;
    const ramadhan = S.bulanHijriyahIni === 'Ramadhan';

    if (cfg.s_tahajud) {
      const hm = wA.Maghrib.match(/(\d\d):(\d\d)/); const hs = wA.Subuh.match(/(\d\d):(\d\d)/);
      if (hm && hs) {
        const tm = +hm[1] * 60 + +hm[2]; let ts = +hs[1] * 60 + +hs[2]; if (ts < tm) ts += 1440;
        const thj = tm + (2 * (ts - tm)) / 3;
        titik(`${String(Math.floor(thj / 60) % 24).padStart(2, '0')}:${String(Math.floor(thj % 60)).padStart(2, '0')}`, 0);
      }
    }
    if (ramadhan) titik(wA.Subuh, -60);
    if (cfg.s_preterbit) titik(wA.Terbit, -10);
    if (cfg.s_terbit) titik(wA.Terbit, 0);
    if (cfg.s_dhuha) titik(wA.Terbit, 20);
    if (cfg.s_istiwa) titik(wA.Dzuhur, -5);
    if (cfg.s_jumat && isJumat) titik('10:00', 0);
    if (cfg.s_imsak || ramadhan) titik(wA.Subuh, -10);
    if (cfg.s_puasa) titik(wA.Maghrib, 10);
    if (cfg.s_kehatihatian) { titik(wA.Ashar, -15); titik(wA.Maghrib, -15); titik(wA.Isya, -15); titik(wA.Subuh, -15); }

    for (const n of WAKTU5) {
      const k = n.toLowerCase(); const w = wA[n];
      const tm = hitungMenitAbsolut(w);
      const adzOn = cfg['adzan_' + k + '_on']; const tarOn = cfg['tarhim_' + k + '_on'];
      const isJumatDzuhur = n === 'Dzuhur' && cfg.s_jumat && isJumat;
      const murOn = cfg['murottal_' + k + '_on'];
      const butuhTar = !!(tarOn || isJumatDzuhur); const butuhMur = !!(murOn || isJumatDzuhur);
      if (tm === -1 || !(adzOn || butuhTar || butuhMur)) continue;

      let pre = 30; // hanya adzan: bangun 30 detik sebelum waktunya
      try {
        let leadT = 6; let infoT = null;
        if (butuhTar) infoT = await siapkanTarhim(n, tgl);
        if (infoT) leadT = tarhimOto() ? infoT.lead : Math.max(0, cfg.waktuTarhim || 0) * 60;
        let menitMur = cfg.waktuMurottal === 0 ? 30 : (cfg.waktuMurottal || 30);
        if (menitMur < 1) menitMur = 30;
        if (!butuhMur) { if (butuhTar) pre = leadT + 60; }
        else pre = (menitMur + Math.ceil(leadT / 60)) * 60 + 120;
        if (butuhMur && murottalOto()) {
          let ms = 0;
          if (murOn) { const infoM = await siapkanMurottal(n, tgl, isJumatDzuhur); ms = infoM ? sisaMurottalMs(infoM) : 0; }
          if (ms > 0) {
            let ekstra = 0;
            for (const kk of ['bumper', 'arham']) {
              const ap = await pilihBerkas(kk, tgl, n);
              if (ap) ekstra += (await durasiFileMs(ap)) / 1000;
            }
            pre = leadT + ekstra + ms / 1000 + 200;
          }
        }
      } catch (e) {}
      catat(tm * 60 - pre, pre + (adzOn ? 90 : 30));
    }

    if (panas) return 0;
    S.detikKeJendela = cfg.s_jam ? Math.min(terdekat, berkala) : terdekat;
    const tidur = Math.floor(Math.min(terdekat, berkala) * 1000);
    if (tidur < 5000) return 0;
    return Math.min(tidur, MAKS);
  } catch (e) { return 0; } // galat hitung: jalan seperti biasa
}

// ============ ALARM PEMBANGUN (cadangan bila proses dimatikan sistem) ============
let idAlarm = null;
export async function jadwalkanAlarmBangun(detikKe) {
  try {
    if (!detikKe || detikKe <= 0 || detikKe >= 86000) return;
    if (idAlarm) await Notifications.cancelScheduledNotificationAsync(idAlarm).catch(() => {});
    const pemicu = new Date(Date.now() + detikKe * 1000 - 5000);
    idAlarm = await Notifications.scheduleNotificationAsync({
      content: { title: 'Jadwal Salat by Reno', body: 'Mesin jadwal dibangunkan. Ketuk untuk membuka aplikasi.', sound: true },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: pemicu, channelId: 'jadwal' },
    });
  } catch (e) {}
}

// ============ SATU SIKLUS PEMERIKSAAN ============
async function siklus() {
  const tgl = tglIni();
  const jamSkrg = jamMenitSekarang().slice(0, 2);
  const menitSkrg = parseInt(jamMenitSekarang().slice(3), 10);

  if (S.tanggalSistem !== tgl) {
    const bersih = {};
    for (const [k, v] of Object.entries(gembok)) if (k.includes(tgl)) bersih[k] = v;
    setGembok(bersih);
    S.tanggalSistem = tgl;
    ambilTanggalHijriyah(0).then((h) => { S.bulanHijriyahIni = (h && h.bln) || ''; });
  }
  const kunci = (k) => gembok[k];
  const kunciSet = (k, v = true) => { gembok[k] = v; simpanGembok(); };

  // alarm pribadi
  if (cfg.alarm_waktu && isWaktunya(cfg.alarm_waktu) && !kunci('ALARM_PRIBADI_' + tgl)) {
    kunciSet('ALARM_PRIBADI_' + tgl);
    const pesan = cfg.alarm_pesan || 'Alarm pribadi berbunyi.';
    putarAudioDenganCallback('sistem', 'bumper', () => tunda(1500, () => bicaraGoogleTTS(pesan, true)));
  }
  // laporan jam
  if (cfg.s_jam && menitSkrg <= 5 && !kunci('JAM_' + tgl + jamSkrg)) {
    kunciSet('JAM_' + tgl + jamSkrg);
    bicaraGoogleTTS(`Jam ${jamSkrg} tepat. ${hitungSisaWaktuTeks().replace(/\n/g, '. ')}`, true);
  }
  // sinkron otomatis bila jadwal hari ini belum ada
  if (cfg.jadwalSebulan && typeof cfg.jadwalSebulan === 'object' && !cfg.jadwalSebulan[tgl] && cfg.idKota !== '' && !kunci('AUTOSYNC_' + tgl + jamSkrg)) {
    kunciSet('AUTOSYNC_' + tgl + jamSkrg);
    sinkronisasiJadwal(cfg.kota).then((r) => { if (r.ok) infoVisual('Jadwal diperbarui otomatis.'); });
  }

  if (!cfg.jadwalSebulan || typeof cfg.jadwalSebulan !== 'object') return;
  const jdw = cfg.jadwalSebulan[tgl];
  if (!jdw || !jdw.Subuh) return;

  const wA = {
    Subuh: tambahMenit(jdw.Subuh, selisihWaktu('Subuh')), Terbit: jdw.Terbit, Dhuha: jdw.Dhuha,
    Dzuhur: tambahMenit(jdw.Dzuhur, selisihWaktu('Dzuhur')), Ashar: tambahMenit(jdw.Ashar, selisihWaktu('Ashar')),
    Maghrib: tambahMenit(jdw.Maghrib, selisihWaktu('Maghrib')), Isya: tambahMenit(jdw.Isya, selisihWaktu('Isya')),
  };
  const isJumat = hariKe() === 5;

  if (cfg.s_tahajud) {
    const hm = wA.Maghrib.match(/(\d\d):(\d\d)/); const hs = wA.Subuh.match(/(\d\d):(\d\d)/);
    if (hm && hs) {
      const tm = +hm[1] * 60 + +hm[2]; let ts = +hs[1] * 60 + +hs[2]; if (ts < tm) ts += 1440;
      const thj = tm + (2 * (ts - tm)) / 3;
      const wThj = `${String(Math.floor(thj / 60) % 24).padStart(2, '0')}:${String(Math.floor(thj % 60)).padStart(2, '0')}`;
      if (isWaktunya(wThj) && !kunci('THJ_' + tgl)) {
        kunciSet('THJ_' + tgl);
        bicaraGoogleTTS(dapatkanTeksVarian('Tahajud'), true, () => tunda(3000, () => putarAudio('sistem', 'tahajud')));
      }
    }
  }

  if (S.bulanHijriyahIni === 'Ramadhan' && isWaktunya(tambahMenit(wA.Subuh, -60)) && !kunci('SAHUR_' + tgl)) {
    kunciSet('SAHUR_' + tgl);
    bicaraGoogleTTS('Waktu sahur telah tiba. Subuh tersisa enam puluh menit lagi.', true, () => tunda(2000, () => putarAudio('sistem', 'sahur')));
  }
  if (cfg.s_preterbit && isWaktunya(tambahMenit(wA.Terbit, -10)) && !kunci('PRETERBIT_' + tgl)) {
    kunciSet('PRETERBIT_' + tgl); putarAudio('sistem', 'peringatanterbit');
  }
  if (cfg.s_terbit && isWaktunya(wA.Terbit) && !kunci('TERBIT_' + tgl)) {
    kunciSet('TERBIT_' + tgl);
    putarAudioDenganCallback('sistem', 'terbit', () => tunda(1500, () => bicaraGoogleTTS('Matahari telah terbit sempurna, waktu larangan sholat telah usai.', true)));
  }
  if (cfg.s_dhuha && isWaktunya(tambahMenit(wA.Terbit, 20)) && !kunci('DHUHA_' + tgl)) {
    kunciSet('DHUHA_' + tgl); putarAudio('sistem', 'dhuha');
  }
  if (cfg.s_istiwa && isWaktunya(tambahMenit(wA.Dzuhur, -5)) && !kunci('ISTIWA_' + tgl)) {
    kunciSet('ISTIWA_' + tgl); bicaraGoogleTTS(dapatkanTeksVarian('Istiwa'), true);
  }

  if (cfg.s_jumat && isJumat) {
    if (isWaktunya('10:00') && !kunci('SJ_' + tgl)) { kunciSet('SJ_' + tgl); bicaraGoogleTTS(dapatkanTeksVarian('Jumat'), true); }
    const infoJ = await siapkanTarhim('Dzuhur', tgl);
    if (infoJ && saatnyaTarhim(wA.Dzuhur, infoJ) && !kunci('SIAPJ_' + tgl)) {
      kunciSet('SIAPJ_' + tgl); jalankanTarhim(infoJ.ap, 'Tarhim Jumat', infoJ.teks);
    }
  }

  if ((cfg.s_imsak || S.bulanHijriyahIni === 'Ramadhan') && isWaktunya(tambahMenit(wA.Subuh, -10)) && !kunci('IMSAK_' + tgl)) {
    kunciSet('IMSAK_' + tgl); bicaraGoogleTTS(dapatkanTeksVarian('Imsak'), true);
  }

  if (cfg.s_puasa && isWaktunya(tambahMenit(wA.Maghrib, 10)) && !kunci('PUASA_' + tgl)) {
    kunciSet('PUASA_' + tgl);
    const bs = (hariKe() + 1) % 7; // hari esok: 1 = Senin, 4 = Kamis
    ambilTanggalHijriyah(1).then((h) => {
      const sunnahHari = () => bs === 1 || bs === 4;
      const namaBs = bs === 1 ? 'Senin' : 'Kamis';
      if (!h) { if (sunnahHari()) bicaraGoogleTTS(`Besok adalah hari ${namaBs}. Jangan lupa berniat puasa sunnah.`, true); return; }
      const { tgl: t, bln } = h; let p = null;
      if (bln === 'Muharram' && t === 9) p = "Besok adalah tanggal 9 Muharram. Jangan lupa berniat puasa sunnah Tasu'a.";
      else if (bln === 'Muharram' && t === 10) p = 'Besok adalah tanggal 10 Muharram. Jangan lupa berniat puasa sunnah Asyura.';
      else if (bln === 'Zulhijah' && t === 8) p = 'Besok adalah tanggal 8 Zulhijah. Jangan lupa berniat puasa sunnah Tarwiyah.';
      else if (bln === 'Zulhijah' && t === 9) p = 'Besok adalah tanggal 9 Zulhijah. Jangan lupa berniat puasa sunnah Arafah.';
      else if (bln === 'Syakban' && t === 15) p = 'Besok adalah Nisfu Syakban. Anda dianjurkan berpuasa sunnah dan memperbanyak ibadah.';
      else if (bln === 'Ramadhan' && t === 1) p = 'Alhamdulillah, besok adalah hari pertama bulan suci Ramadhan. Jangan lupa berniat puasa wajib.';
      else if (bln === 'Syawal' && t >= 2 && t <= 7) p = `Besok adalah tanggal ${t} Syawal. Mari rutinkan puasa sunnah enam hari Syawal.`;
      else if ((t === 13 || t === 14 || t === 15) && bln !== 'Ramadhan' && !(bln === 'Zulhijah' && t === 13)) p = `Besok masuk puasa sunnah Ayyamul Bidh tanggal ${t} ${bln}.`;
      else if (sunnahHari()) p = `Besok adalah hari ${namaBs}. Jangan lupa berniat puasa sunnah.`;
      if (p) bicaraGoogleTTS(p, true);
    });
  }

  if (cfg.s_kehatihatian) {
    const akhir = [{ c: 'Dzuhur', n: wA.Ashar }, { c: 'Ashar', n: wA.Maghrib }, { c: 'Maghrib', n: wA.Isya }, { c: 'Isya', n: wA.Subuh }];
    for (const wp of akhir) {
      if (isWaktunya(tambahMenit(wp.n, -15)) && !kunci('HATI_' + wp.c + tgl)) {
        kunciSet('HATI_' + wp.c + tgl); bicaraGoogleTTS(dapatkanTeksVarian('Kehati', wp.c), true);
      }
    }
  }

  // ---- lima waktu salat ----
  for (const n of WAKTU5) {
    const k = n.toLowerCase();
    const w = { n, w: wA[n], adzOn: cfg['adzan_' + k + '_on'], tarOn: cfg['tarhim_' + k + '_on'] };
    const isJumatDzuhur = n === 'Dzuhur' && cfg.s_jumat && isJumat;

    let infoT = null;
    if (w.tarOn || isJumatDzuhur) infoT = await siapkanTarhim(n, tgl);

    if (w.tarOn && infoT && !isJumatDzuhur && saatnyaTarhim(w.w, infoT) && !kunci('TARHIM_' + n + tgl)) {
      kunciSet('TARHIM_' + n + tgl); jalankanTarhim(infoT.ap, 'Tarhim ' + n, infoT.teks);
    }

    const murOn = cfg['murottal_' + k + '_on'];
    const teksAwal = (murOn || isJumatDzuhur) ? susunTeksAwal(n) : '';
    const teksJ = murOn ? "Mendekati waktu sholat Jumat. Memutar Murottal Al-Jumu'ah." : 'Mendekati waktu sholat Jumat.';
    const jedaMur = (cfg.waktuMurottal === 0 || (n === 'Subuh' && cfg.waktuArham === 0)) ? 0 : 3000;
    const jedaArham = cfg.waktuMurottal === 0 ? 0 : 1000;
    let infoM = null; let siapMur = false;
    let menitMur = cfg.waktuMurottal === 0 ? 30 : cfg.waktuMurottal;
    let leadT = 6;
    if (infoT) leadT = tarhimOto() ? infoT.lead : cfg.waktuTarhim * 60;

    if (!(murOn || isJumatDzuhur)) siapMur = false;
    else if (murottalOto()) {
      if (cfg.waktuMurottal < 1) menitMur = 30;
      if (murOn) infoM = await siapkanMurottal(n, tgl, isJumatDzuhur);
      const msM = infoM ? sisaMurottalMs(infoM) : 0;
      if (msM > 0) {
        let pra = 0;
        if (isJumatDzuhur) pra = Math.max(2.5, teksJ.length * 0.1) + jedaMur / 1000;
        else {
          const pBumper = await pilihBerkas('bumper', tgl, n);
          if (pBumper) pra += (await durasiFileMs(pBumper)) / 1000 + 2;
          pra += Math.max(2.5, teksAwal.length * 0.1) + jedaMur / 1000;
          if (n === 'Subuh' && cfg.waktuArham > 0) {
            const pArham = await pilihBerkas('arham', tgl, n);
            if (pArham) pra += (await durasiFileMs(pArham)) / 1000 + jedaArham / 1000;
          }
        }
        const totalMur = leadT + pra + msM / 1000 + 10;
        const tm = hitungMenitAbsolut(w.w);
        if (tm !== -1) {
          const sisa = (tm * 60 - detikHariIni() + 86400) % 86400;
          siapMur = sisa <= totalMur && sisa > leadT + 60;
        }
      } else {
        infoM = null; // murottal nonaktif / berkas tak ada: pengumuman tetap sebelum tarhim
        siapMur = isWaktunya(tambahMenit(w.w, -(menitMur + Math.ceil(leadT / 60))));
      }
    } else {
      if (infoT && tarhimOto()) menitMur += Math.ceil(leadT / 60);
      siapMur = isWaktunya(tambahMenit(w.w, -menitMur));
    }

    if (siapMur && !kunci('MUR_' + n + tgl)) {
      kunciSet('MUR_' + n + tgl);
      const pathM = infoM ? infoM.ap : null;
      const putarArhamDanMurottal = async () => {
        if (!murOn) return;
        if (cfg.waktuArham > 0 && n === 'Subuh') {
          const pArham = await pilihBerkas('arham', tgl, n);
          if (pArham) {
            putarAudioFileLangsung(pArham, 'Arhamarrohimin', 'sistem', () => tunda(jedaArham, () => putarAudio('murottal', n, pathM)));
            return;
          }
        }
        putarAudio('murottal', n, pathM);
      };
      if (cfg.getarAwal) getar(300);
      if (isJumatDzuhur) {
        bicaraGoogleTTS(teksJ, true, () => { if (murOn) tunda(jedaMur, () => putarAudio('murottal', 'aljumuah', pathM)); });
      } else {
        const ap = await pilihBerkas('bumper', tgl, n);
        if (ap) {
          eksekusiAutoVolume(() => {
            putarAudioFileLangsung(ap, 'bumper', 'sistem', () => {
              tunda(2000, () => bicaraGoogleTTS(teksAwal, true, () => tunda(jedaMur, () => { putarArhamDanMurottal(); kembalikanVolume(); })));
            });
          });
        } else {
          bicaraGoogleTTS(teksAwal, true, () => tunda(jedaMur, () => putarArhamDanMurottal()));
        }
      }
    }

    // ---- adzan ----
    let tungguTarhim = false;
    if (S.tarhimBerjalan && nowSec() - (S.tarhimMulai || 0) < 900) {
      const lewat = (detikHariIni() - hitungMenitAbsolut(w.w) * 60 + 86400) % 86400;
      if (lewat < 30 && !cfg.deteksiOtomatis) tungguTarhim = true; // adzan menunggu tarhim maks. 30 detik
    }
    if (isWaktunya(w.w) && !tungguTarhim && !kunci('ADZ_' + n + tgl)) {
      kunciSet('ADZ_' + n + tgl);
      if (!(n === 'Dzuhur' && cfg.s_jumat && isJumat)) {
        if (w.adzOn) {
          hentikanAudioDanSimpan(); eksekusiModeKhusyuk(cfg.durasiKhusyuk, n);
          eksekusiAutoVolume(() => tunda(2500, () => { putarAudio('adzan', n); kembalikanVolume(); }));
          if (cfg.iqomah_on) kunciSet('IQOMAH_' + n + tgl, tambahMenit(w.w, cfg.waktuIqomah));
        } else infoVisual(`Waktu ${n} telah masuk. Adzan otomatis dinonaktifkan.`);
      }
    }

    // ---- iqomah ----
    const kI = 'IQOMAH_' + n + tgl;
    if (typeof gembok[kI] === 'string' && isWaktunya(gembok[kI])) {
      if (sedangMain()) kunciSet(kI, tambahMenit(gembok[kI], 1));
      else {
        delete gembok[kI]; simpanGembok();
        if (w.adzOn && cfg.iqomah_on) bicaraGoogleTTS(dapatkanTeksVarian('Iqomah'), true, () => tunda(3000, () => putarAudio('sistem', 'iqomah')));
      }
    }
  }
}

// ============ LOOP UTAMA ============
export async function mesinWaktuMasjid(idSesi) {
  const sesiSaya = idSesi || S.sesiMesin;
  if (S.sesiMesin !== sesiSaya) return;
  S.detakJantung = Date.now();
  jagaMesinTetapHidup();

  if (!cfg.master_aktif) { matikanPenjagaSunyi(); tunda(120000, () => mesinWaktuMasjid(sesiSaya)); return; }

  const jeda = await hitungTundaMesin();
  S.mesinPanas = jeda === 0;
  perbaruiNotifLayanan(hitungSisaWaktuTeks());
  if (jeda > 0) {
    jadwalkanAlarmBangun(S.detikKeJendela);
    tunda(jeda, () => mesinWaktuMasjid(sesiSaya));
    return;
  }
  try { await siklus(); } catch (e) { /* satu siklus gagal tidak boleh menghentikan mesin */ }
  tunda(5000, () => mesinWaktuMasjid(sesiSaya));
}

export function mulaiMesin(tundaMs = 1000) {
  if (!S.tanggalSistem) S.tanggalSistem = tglIni();
  S.sesiMesin += 1;
  const id = S.sesiMesin;
  tunda(tundaMs, () => mesinWaktuMasjid(id));
}

export function hentikanMesin() { S.sesiMesin += 1; matikanPenjagaSunyi(); matikanLayanan(); }

// Pengawas: bila mesin tak berdetak > 10 menit, mulai ulang
export function mulaiWatchdog() {
  if (S.watchdogAktif) return;
  S.watchdogAktif = true;
  const cek = () => {
    if (Date.now() - S.detakJantung > 600000) mulaiMesin(1000);
    tunda(300000, cek);
  };
  tunda(300000, cek);
}
