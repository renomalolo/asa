// Helper sistem Android
import { Linking } from 'react-native';
import * as IntentLauncher from 'expo-intent-launcher';

export const NAMA_PAKET = 'com.JadwalSolad.ByReno';

// Minta pengecualian optimasi baterai supaya jadwal tetap berjalan di latar belakang
export async function bukaPengaturanBaterai() {
  try {
    await IntentLauncher.startActivityAsync('android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS', { data: 'package:' + NAMA_PAKET });
  } catch (e) {
    try { await IntentLauncher.startActivityAsync('android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS'); }
    catch (e2) { Linking.openSettings(); }
  }
}
