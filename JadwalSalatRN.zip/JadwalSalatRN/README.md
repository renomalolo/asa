# Jadwal Salat by Reno — versi React Native (Expo)

Port dari aplikasi AndLua+ (`main.lua`) ke JavaScript / React Native.
**Belum diuji di perangkat** — dibuat dengan membaca kode sumber Lua. Uji dulu sebelum dipakai untuk jadwal sungguhan.

## Cara membangun (Android)

Butuh Node.js, JDK 17, dan Android Studio (SDK). Tidak bisa dijalankan di Expo Go (ada modul native).

```bash
npm install expo@latest
npx expo install react react-native expo-audio expo-speech expo-location expo-file-system expo-asset \
  expo-notifications expo-sensors expo-clipboard expo-document-picker expo-intent-launcher \
  @react-native-async-storage/async-storage
npm install react-native-volume-manager react-native-background-actions
npx expo run:android          # sambungkan HP dengan USB debugging
```

Saat pertama dibuka, audio bawaan (`assets/audio`) disalin ke folder aplikasi. Izinkan notifikasi & lokasi,
lalu di menu utama tekan **BUKA PENGATURAN BATERAI** dan pilih "Tidak dibatasi".

## Peta file

| Lua (main.lua) | JavaScript |
|---|---|
| config / gembok / `_G.*` | `src/store.js`, `src/state.js` |
| waktu, tanggal, pasaran | `src/waktu.js` |
| API myquran / aladhan | `src/api.js` |
| radar audio, pemutar, TTS, tarhim, rantai adzan | `src/audio.js` |
| `mesinWaktuMasjid`, `hitungTundaMesin`, watchdog | `src/engine.js` |
| lokasi otomatis | `src/lokasi.js` |
| layanan latar (pengganti wakelock+AlarmManager) | `src/layanan.js`, `plugins/withBackgroundActions.js` |
| semua menu dialog | `src/screens/*` |

## Perbedaan dari versi Lua

- **Jalur keluaran suara** (Media/Dering/Alarm/Notifikasi): dihapus; `expo-audio` tidak bisa memilih stream.
- **Folder audio**: sekarang di penyimpanan internal app. Tambah berkas lewat tombol *Tambah berkas audio* di Memori Murottal.
  Berkas di `audio/murottal/` kini ikut disalin ke folder yang sama.
- **Keep-alive**: layanan latar depan (`mediaPlayback`) + audio hening opsional (Pengaturan Cerdas → Penjaga sunyi).
  Alarm pembangun memakai notifikasi terjadwal; bila proses dimatikan sistem, Anda harus mengetuknya.
- **Radar Kiblat**: memakai magnetometer (ponsel mendatar), tanpa kompensasi kemiringan.
- **Mode Khusyuk / By-pass volume**: via `react-native-volume-manager`; mode getar butuh akses "Jangan Ganggu".
- Tombol Kembali di menu utama menyembunyikan app (perilaku Android 12+), mesin tetap jalan.
