// Config plugin: mendaftarkan layanan react-native-background-actions di AndroidManifest
// dengan tipe "mediaPlayback" (tanpa batas waktu seperti dataSync di Android 15+).
const { withAndroidManifest, AndroidConfig } = require('@expo/config-plugins');

module.exports = function withBackgroundActions(config) {
  return withAndroidManifest(config, (c) => {
    const manifest = c.modResults.manifest;
    manifest['uses-permission'] = manifest['uses-permission'] || [];
    for (const p of ['FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PLAYBACK', 'WAKE_LOCK']) {
      const nama = 'android.permission.' + p;
      if (!manifest['uses-permission'].some((x) => x.$['android:name'] === nama)) {
        manifest['uses-permission'].push({ $: { 'android:name': nama } });
      }
    }
    const app = AndroidConfig.Manifest.getMainApplicationOrThrow(c.modResults);
    app.service = app.service || [];
    const namaLayanan = 'com.asterinet.react.bgactions.RNBackgroundActionsTask';
    const ada = app.service.find((x) => x.$['android:name'] === namaLayanan);
    if (ada) ada.$['android:foregroundServiceType'] = 'mediaPlayback';
    else app.service.push({ $: { 'android:name': namaLayanan, 'android:foregroundServiceType': 'mediaPlayback' } });
    return c;
  });
};
